#pragma once

void StartThread();
void StopThread();
void SetInputVal(int val);
