#include "Threading_dotNet_CPP.h"

#if 0
int main()
{

    // start a managed thread..
    StartThread();

    for(int x = 0; x < 12; x++)
    {
        mt->SetInputVal(x);

        Thread::Sleep(410);
    }
    mt->StopThread();
    // call it from native code..


    return 0;
}
#endif