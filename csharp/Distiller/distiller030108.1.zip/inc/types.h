/***********************************************************************************

    Filename: types.h

    Description: Definition of the extremely common datatypes.

    Copyright (c) 2007 Universal Electronics, Inc.

History:

 Date       Author      Description
--------------------------------------------------------------------------------------------------
02/01/08    ryoung      Imported.
***********************************************************************************/
#ifndef TYPES_H
#define TYPES_H


typedef unsigned char       u8;
typedef unsigned short      u16;
typedef unsigned long       u32;
typedef char         		s8;
typedef short        		s16;
typedef long         		s32;

typedef enum { true = 1, false = 0 }bool;

#ifndef NULL
   #define NULL 0
#endif

#ifndef HIGH
   #define HIGH 1
#endif

#ifndef LOW
   #define LOW 0
#endif

#endif // TYPES_H
