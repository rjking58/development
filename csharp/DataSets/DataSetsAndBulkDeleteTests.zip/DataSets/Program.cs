using System;
using System.Collections.Generic;
using System.Text;

using System.Data;

namespace DataSets
{
    class Program
    {
        static void Main(string[] args)
        {
            // our dataset..
            DataSet carsInventoryDS = new DataSet("Car Inventory");
            carsInventoryDS.ExtendedProperties["TimeStamp"] = DateTime.Now;
            carsInventoryDS.ExtendedProperties["Company"] = "UEI training";
            
            DataColumn carIDColumn = new DataColumn("CarID",typeof(int));
            carIDColumn.Caption = "Car ID";
            carIDColumn.ReadOnly = true;
            carIDColumn.AllowDBNull = false;
            carIDColumn.Unique = true;
            carIDColumn.AutoIncrement = true;
            carIDColumn.AutoIncrementSeed = 0;
            carIDColumn.AutoIncrementStep = 1;
            
            DataColumn carMakeColumn = new DataColumn("Make",typeof(string));
            DataColumn carColorColumn = new DataColumn("Color",typeof(string));
            DataColumn carPetNameColumn = new DataColumn("PetName",typeof(string));
            carPetNameColumn.Caption = "Pet Name";
            
            DataTable inventoryTable = new DataTable("Inventory");
            inventoryTable.Columns.AddRange(new DataColumn[] {carIDColumn,
                                                              carMakeColumn,
                                                              carColorColumn,
                                                              carPetNameColumn});
                                                              
            // populate with some data..
            DataRow rowToAdd1 = inventoryTable.NewRow();
            rowToAdd1["Make"] = "BMW";
            rowToAdd1["Color"] = "Black";
            rowToAdd1["PetName"] = "Hamlet";
            inventoryTable.Rows.Add(rowToAdd1);
            
            DataRow rowToAdd2 = inventoryTable.NewRow();
            rowToAdd2["Make"] = "SAAB";
            rowToAdd2["Color"] = "Red";
            rowToAdd2["PetName"] = "Sea Breeze";
            inventoryTable.Rows.Add(rowToAdd2);
            
            Console.WriteLine(rowToAdd1.RowState);
            Console.WriteLine(rowToAdd2.RowState);

            Console.WriteLine("Accepting Changes");
            inventoryTable.AcceptChanges();

            Console.WriteLine(rowToAdd1.RowState);
            Console.WriteLine(rowToAdd2.RowState);
            Console.WriteLine();
            
            for(int curCol = 0; curCol < inventoryTable.Columns.Count;curCol++)
            {
                Console.Write(inventoryTable.Columns[curCol].ColumnName.Trim() + "\t");
            }
            Console.WriteLine("\n------------------------------------");
            for(int curRow = 0; curRow < inventoryTable.Rows.Count; curRow++)
            {
                for(int curCol = 0; curCol < inventoryTable.Columns.Count;curCol++)
                {
                    Console.Write(inventoryTable.Rows[curRow][curCol].ToString() + "\t");
                }
                Console.WriteLine();
            }
            
        }
        
        static void ShowRowState(DataRow dr)
        {
            Console.WriteLine(dr.RowState);
        }
    }
}
