﻿namespace DataWizInConsoleTest {


    partial class SerializedTestDS
    {
    }
}
