Tailspin Spyworks tutorial for ASP.NET 4 - v0.8 release

The code and tutorial can be downloaded from http://tailspinspyworks.codeplex.com/

The code for this project is available under the Microsoft Public License (Ms-PL). The tutorial document is licensed under Creative Commons Attribution 3.0 License.

For more information, see the included tutorial document PDF.