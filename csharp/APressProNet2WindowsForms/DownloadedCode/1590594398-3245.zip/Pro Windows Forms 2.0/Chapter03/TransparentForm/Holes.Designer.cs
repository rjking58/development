namespace TransparentForm
{
	partial class Holes
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.PictureBox4 = new System.Windows.Forms.PictureBox();
			this.PictureBox2 = new System.Windows.Forms.PictureBox();
			this.PictureBox1 = new System.Windows.Forms.PictureBox();
			this.PictureBox3 = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
			this.SuspendLayout();
			// 
			// PictureBox4
			// 
			this.PictureBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
			this.PictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.PictureBox4.Location = new System.Drawing.Point(156, 141);
			this.PictureBox4.Name = "PictureBox4";
			this.PictureBox4.Size = new System.Drawing.Size(76, 76);
			this.PictureBox4.TabIndex = 14;
			this.PictureBox4.TabStop = false;
			// 
			// PictureBox2
			// 
			this.PictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
			this.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.PictureBox2.Location = new System.Drawing.Point(60, 141);
			this.PictureBox2.Name = "PictureBox2";
			this.PictureBox2.Size = new System.Drawing.Size(76, 76);
			this.PictureBox2.TabIndex = 13;
			this.PictureBox2.TabStop = false;
			// 
			// PictureBox1
			// 
			this.PictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
			this.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.PictureBox1.Location = new System.Drawing.Point(156, 49);
			this.PictureBox1.Name = "PictureBox1";
			this.PictureBox1.Size = new System.Drawing.Size(76, 76);
			this.PictureBox1.TabIndex = 12;
			this.PictureBox1.TabStop = false;
			// 
			// PictureBox3
			// 
			this.PictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
			this.PictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.PictureBox3.Location = new System.Drawing.Point(60, 49);
			this.PictureBox3.Name = "PictureBox3";
			this.PictureBox3.Size = new System.Drawing.Size(76, 76);
			this.PictureBox3.TabIndex = 11;
			this.PictureBox3.TabStop = false;
			// 
			// Holes
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.Add(this.PictureBox4);
			this.Controls.Add(this.PictureBox2);
			this.Controls.Add(this.PictureBox1);
			this.Controls.Add(this.PictureBox3);
			this.Name = "Holes";
			this.Text = "Holes";
			this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
			((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.PictureBox PictureBox4;
		private System.Windows.Forms.PictureBox PictureBox2;
		private System.Windows.Forms.PictureBox PictureBox1;
		private System.Windows.Forms.PictureBox PictureBox3;
	}
}