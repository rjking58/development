namespace Scrolling
{
	partial class ScrollableForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Panel1 = new System.Windows.Forms.Panel();
			this.Button6 = new System.Windows.Forms.Button();
			this.Button5 = new System.Windows.Forms.Button();
			this.Button4 = new System.Windows.Forms.Button();
			this.Button3 = new System.Windows.Forms.Button();
			this.Button2 = new System.Windows.Forms.Button();
			this.Button1 = new System.Windows.Forms.Button();
			this.Panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// Panel1
			// 
			this.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.Panel1.Controls.Add(this.Button6);
			this.Panel1.Controls.Add(this.Button5);
			this.Panel1.Controls.Add(this.Button4);
			this.Panel1.Controls.Add(this.Button3);
			this.Panel1.Controls.Add(this.Button2);
			this.Panel1.Controls.Add(this.Button1);
			this.Panel1.Location = new System.Drawing.Point(14, 15);
			this.Panel1.Name = "Panel1";
			this.Panel1.Size = new System.Drawing.Size(264, 237);
			this.Panel1.TabIndex = 3;
			// 
			// Button6
			// 
			this.Button6.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Button6.Location = new System.Drawing.Point(16, 180);
			this.Button6.Name = "Button6";
			this.Button6.Size = new System.Drawing.Size(168, 24);
			this.Button6.TabIndex = 5;
			this.Button6.Text = "Button6";
			// 
			// Button5
			// 
			this.Button5.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Button5.Location = new System.Drawing.Point(16, 148);
			this.Button5.Name = "Button5";
			this.Button5.Size = new System.Drawing.Size(168, 24);
			this.Button5.TabIndex = 4;
			this.Button5.Text = "Button5";
			// 
			// Button4
			// 
			this.Button4.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Button4.Location = new System.Drawing.Point(16, 116);
			this.Button4.Name = "Button4";
			this.Button4.Size = new System.Drawing.Size(168, 24);
			this.Button4.TabIndex = 3;
			this.Button4.Text = "Button4";
			// 
			// Button3
			// 
			this.Button3.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Button3.Location = new System.Drawing.Point(16, 84);
			this.Button3.Name = "Button3";
			this.Button3.Size = new System.Drawing.Size(168, 24);
			this.Button3.TabIndex = 2;
			this.Button3.Text = "Button3";
			// 
			// Button2
			// 
			this.Button2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Button2.Location = new System.Drawing.Point(16, 52);
			this.Button2.Name = "Button2";
			this.Button2.Size = new System.Drawing.Size(168, 24);
			this.Button2.TabIndex = 1;
			this.Button2.Text = "Button2";
			// 
			// Button1
			// 
			this.Button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.Button1.Location = new System.Drawing.Point(16, 20);
			this.Button1.Name = "Button1";
			this.Button1.Size = new System.Drawing.Size(168, 24);
			this.Button1.TabIndex = 0;
			this.Button1.Text = "Button1";
			// 
			// ScrollableForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.AutoScroll = true;
			this.ClientSize = new System.Drawing.Size(172, 165);
			this.Controls.Add(this.Panel1);
			this.Name = "ScrollableForm";
			this.Text = "Form1";
			this.Panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel Panel1;
		private System.Windows.Forms.Button Button6;
		private System.Windows.Forms.Button Button5;
		private System.Windows.Forms.Button Button4;
		private System.Windows.Forms.Button Button3;
		private System.Windows.Forms.Button Button2;
		private System.Windows.Forms.Button Button1;
	}
}

