﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EnumerableUsage
{
    class IntCollection : IEnumerable
    {
        private int[] intArray = {4,7,11,33,42};

        public IntCollection()
        {

        }

        #region IEnumerable Members

        public IEnumerator GetEnumerator()
        {
            foreach(int i in intArray)
            {
                if((i % 2 ) == 0)
                {
                    yield return i;
                }
            }
        }

        #endregion
    }
    class Program
    {
        static void Main(string[] args)
        {
            IntCollection ic = new IntCollection();

            foreach( int i in ic)
            {
                Console.WriteLine(i);
            }
        }
    }
}
