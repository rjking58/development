#pragma once

#ifdef AUTOLINKDLL_EXPORTS
__declspec(dllexport) void Testcall();
#else
__declspec(dllimport) void Testcall();
#endif