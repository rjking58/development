/*******************************************************************
 *         Advanced 3D Game Programming using DirectX 9.0
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * copyright (c) 2003 by Peter A Walsh and Adrian Perez
 * See license.txt for modification and distribution information
 ******************************************************************/

#if !defined(AFX_GAMESERVER2_H__73097133_36BF_48B8_ADD2_C8AD8F8DB34D__INCLUDED_)
#define AFX_GAMESERVER2_H__73097133_36BF_48B8_ADD2_C8AD8F8DB34D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"


#endif // !defined(AFX_GAMESERVER2_H__73097133_36BF_48B8_ADD2_C8AD8F8DB34D__INCLUDED_)
