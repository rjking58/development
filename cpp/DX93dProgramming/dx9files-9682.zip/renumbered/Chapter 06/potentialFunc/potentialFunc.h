/*******************************************************************
 *         Advanced 3D Game Programming using DirectX 9.0
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * copyright (c) 2003 by Peter A Walsh and Adrian Perez
 * See license.txt for modification and distribution information
 ******************************************************************/

#if !defined(AFX_POTENTIALFUNC_H__609CF8C5_A826_11D3_95D0_00600831EEE7__INCLUDED_)
#define AFX_POTENTIALFUNC_H__609CF8C5_A826_11D3_95D0_00600831EEE7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"


#endif // !defined(AFX_POTENTIALFUNC_H__609CF8C5_A826_11D3_95D0_00600831EEE7__INCLUDED_)
