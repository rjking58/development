/*******************************************************************
 *         Advanced 3D Game Programming using DirectX 9.0
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * copyright (c) 2003 by Peter A Walsh and Adrian Perez
 ******************************************************************/

#if !defined(AFX_HELLOWORLD_H__C959CF26_5A86_11D3_A6CF_00600831EEE7__INCLUDED_)
#define AFX_HELLOWORLD_H__C959CF26_5A86_11D3_A6CF_00600831EEE7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"


#endif // !defined(AFX_HELLOWORLD_H__C959CF26_5A86_11D3_A6CF_00600831EEE7__INCLUDED_)
