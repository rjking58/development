/*******************************************************************
 *         Advanced 3D Game Programming using DirectX 9.0
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *   Title: ReadMe.txt
 *    Desc: Info on the chapter 1 code
 * copyright (c) 2002 by Peter A Walsh and Adrian Perez
 ******************************************************************/

The chapter 1 workspace has the following projects
HelloWorld (Application)

/******************************************************************/
Application Name: HelloWorld

Application Description: 
    This is provided as a sanity check for people with zero 
    experience with windows programming.  It is a stripped
    down version of the default win32 project that Visual C
    creates.

Executable flags:
    None.

