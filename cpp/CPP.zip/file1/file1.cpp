#include <fstream.h>

void main()
{
	ofstream	str1("test.out");

	str1 << "hi there" << endl;
}