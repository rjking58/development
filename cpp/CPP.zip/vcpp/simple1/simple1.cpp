#include <iostream.h>
#include <strstrea.h>
#include <process.h>

void main()
{
	int	a_num;

	cout << "Enter a number:";
	cin >> a_num;

	exit(a_num);
}