#include <iostream.h>


void main(void)
{

	const i1 = 20;
	const int * const i1_p = &
}