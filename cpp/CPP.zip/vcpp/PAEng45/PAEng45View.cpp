// PAEng45View.cpp : implementation of the CPAEng45View class
//

#include "stdafx.h"
#include "PAEng45.h"

#include "PAEng45Doc.h"
#include "PAEng45View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPAEng45View

IMPLEMENT_DYNCREATE(CPAEng45View, CView)

BEGIN_MESSAGE_MAP(CPAEng45View, CView)
	//{{AFX_MSG_MAP(CPAEng45View)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPAEng45View construction/destruction

CPAEng45View::CPAEng45View()
{
	// TODO: add construction code here

}

CPAEng45View::~CPAEng45View()
{
}

BOOL CPAEng45View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPAEng45View drawing

void CPAEng45View::OnDraw(CDC* pDC)
{
	CPAEng45Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CPAEng45View printing

BOOL CPAEng45View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CPAEng45View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CPAEng45View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CPAEng45View diagnostics

#ifdef _DEBUG
void CPAEng45View::AssertValid() const
{
	CView::AssertValid();
}

void CPAEng45View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPAEng45Doc* CPAEng45View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPAEng45Doc)));
	return (CPAEng45Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPAEng45View message handlers
