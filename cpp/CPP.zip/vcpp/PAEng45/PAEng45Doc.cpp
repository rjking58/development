// PAEng45Doc.cpp : implementation of the CPAEng45Doc class
//

#include "stdafx.h"
#include "PAEng45.h"

#include "PAEng45Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPAEng45Doc

IMPLEMENT_DYNCREATE(CPAEng45Doc, CDocument)

BEGIN_MESSAGE_MAP(CPAEng45Doc, CDocument)
	//{{AFX_MSG_MAP(CPAEng45Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPAEng45Doc construction/destruction

CPAEng45Doc::CPAEng45Doc()
{
	// TODO: add one-time construction code here

}

CPAEng45Doc::~CPAEng45Doc()
{
}

BOOL CPAEng45Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CPAEng45Doc serialization

void CPAEng45Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CPAEng45Doc diagnostics

#ifdef _DEBUG
void CPAEng45Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPAEng45Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPAEng45Doc commands
