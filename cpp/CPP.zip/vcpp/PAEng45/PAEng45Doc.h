// PAEng45Doc.h : interface of the CPAEng45Doc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PAENG45DOC_H__25A78388_0806_11D3_9696_00C04FA31DA8__INCLUDED_)
#define AFX_PAENG45DOC_H__25A78388_0806_11D3_9696_00C04FA31DA8__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CPAEng45Doc : public CDocument
{
protected: // create from serialization only
	CPAEng45Doc();
	DECLARE_DYNCREATE(CPAEng45Doc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPAEng45Doc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPAEng45Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPAEng45Doc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAENG45DOC_H__25A78388_0806_11D3_9696_00C04FA31DA8__INCLUDED_)
