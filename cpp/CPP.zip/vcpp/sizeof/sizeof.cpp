#include <iostream.h>


void main()
{

	int ar1[10];

	cout << (sizeof(ar1)/sizeof(int)) << endl;;

}