#include <iostream.h>


main()
{
   for(int i = 0; i < 16; i++)
   {
      cout << "i:" << i << " i mod 8:" << (i % 8) << endl;
   }
}