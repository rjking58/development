
#include "stdafx.h"
#include "MultiThread1.h"
#include <strstrea.h>
#include "ThreadFunc.h"
#include "TreadDiag.h"

CCriticalSection cs;

UINT ThreadFunction( LPVOID pParam )
{
	CTreadDiag *ParentD = (CTreadDiag *) pParam;
	int MyID = ParentD->GetID();
	HWND hWndPtr = ParentD->m_hWnd;

	for(int x = 1; x< 11; x++)
	{
		ostrstream outpt;

		outpt << "(" << MyID << ") message #" << x << ends;
//		cs.Lock();
		ParentD->AddString(outpt.str(),TRUE);

		PostMessage(hWndPtr,WM_USER_UPDATE_THREADDIAG,0,0);
//		cs.Unlock();
		outpt.rdbuf()->freeze(0);
		::Sleep(500);
	}
	return 1;
}