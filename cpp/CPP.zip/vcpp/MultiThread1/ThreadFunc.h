
#ifndef THREADFUNC_H
#define THREADFUNC_H

#include <afxmt.h>

UINT ThreadFunction( LPVOID pParam );

#endif THREADFUNC_H
