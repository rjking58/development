// tree2View.cpp : implementation of the CTree2View class
//

#include "stdafx.h"
#include "tree2.h"

#include "tree2Doc.h"
#include "tree2View.h"
#include "dirintfc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTree2View

IMPLEMENT_DYNCREATE(CTree2View, CTreeView)

BEGIN_MESSAGE_MAP(CTree2View, CTreeView)
	//{{AFX_MSG_MAP(CTree2View)
	ON_NOTIFY_REFLECT(TVN_SELCHANGED, OnSelchanged)
	ON_COMMAND(ID_ACTION_CHANGEIMAGE, OnMenuchangeimage)
	ON_COMMAND(ID_ACTION_CHANGEIMAGEBACK, OnActionChangeimageback)
	ON_NOTIFY_REFLECT(NM_RCLICK, OnRclick)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CTreeView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CTreeView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CTreeView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTree2View construction/destruction

CTree2View::CTree2View()
	: m_aDE("C:\\EffectiveC++","C:\\EffectiveC++")
{
	// TODO: add construction code here

}

CTree2View::~CTree2View()
{
}

BOOL CTree2View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CTreeView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTree2View drawing

void CTree2View::OnDraw(CDC* pDC)
{
	CTree2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CTree2View printing

BOOL CTree2View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTree2View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTree2View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTree2View diagnostics

#ifdef _DEBUG
void CTree2View::AssertValid() const
{
	CTreeView::AssertValid();
}

void CTree2View::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}

CTree2Doc* CTree2View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTree2Doc)));
	return (CTree2Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTree2View message handlers

void CTree2View::OnInitialUpdate() 
{

	const int			NodeNamesz = 100;
	CTreeCtrl			&TreeCtrl =	GetTreeCtrl( );
	long					Styles;


	// TODO: Add your specialized code here and/or call the base class
	// setup the extra's on the tree view...

	Styles = GetWindowLong(	m_hWnd,		// handle of window
									GWL_STYLE	// offset of value to set
					  								// new value
									);	
	Styles |= (		TVS_HASLINES 
					|	TVS_HASBUTTONS 
					|	TVS_LINESATROOT 
					|	TVS_SHOWSELALWAYS );

	SetWindowLong(	m_hWnd,	// handle of window
					GWL_STYLE,	// offset of value to set
					Styles	  	// new value
				  );	



	//CBitmap
   // mTheBitMap.LoadBitmap( IDB_TREEIMAGES );

	// image list
	// mTheImageList.Add(&mTheBitMap,(CBitmap *) 0);
	mTheImageList.Create( IDB_TREEIMAGES, 14,0, RGB(10,10,10) );
	// TREE stuff.
	TreeCtrl.SetImageList( &mTheImageList, TVSIL_NORMAL);


	m_aDE.Initialize(TreeCtrl);
	Invalidate(TRUE);	

}



void CTree2View::OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

	TV_ITEM	*Old = &(pNMTreeView->itemOld);
	TV_ITEM *New = &(pNMTreeView->itemNew);
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CTree2View::OnMenuchangeimage() 
{
	// TODO: Add your command handler code here
	CTreeCtrl			&TreeCtrl =	GetTreeCtrl( );
	m_aDE.ChangeImage(TreeCtrl);
	Invalidate(TRUE);	
	
}

void CTree2View::OnActionChangeimageback() 
{
	// TODO: Add your command handler code here
	CTreeCtrl			&TreeCtrl =	GetTreeCtrl( );
	m_aDE.ChangeImageBack(TreeCtrl);
	Invalidate(TRUE);	
	
}




void CTree2View::OnRclick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here

	//	AfxGetApp()->GetMainWnd()->PostMessage(WM_CLOSE);
	
	*pResult = 0;
}
