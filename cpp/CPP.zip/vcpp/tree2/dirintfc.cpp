

#include <stdafx.h>
#include "dirintfc.h"
#include <assert.h>
#include <string.h>
#include <iostream.h>
#include <strstrea.h>


long FSystemEntry::mCurrentItemID = 1;


CString	FileEntry::GetName()
{
	return mFileName;
}

HTREEITEM	FileEntry::GetTreeItem()
{
	return mTreeItemHandle;
}


void FileEntry::PrintInfo()
{
	// nothing for now.
}
unsigned long FileEntry::Initialize(CTreeCtrl	&TreeCtrl)
{
	ostrstream TStr;


	TStr << mFileName << "(" << mFileData.nFileSizeLow << ")" << ends;

	// nothing for now..
	mTreeStruct.hParent = GetParent()->GetTreeItem();
	mTreeStruct.hInsertAfter = TVI_SORT;
	mTreeStruct.item.mask = TVIF_TEXT | TVIF_PARAM;
	mTreeStruct.item.pszText = TStr.str();
	mTreeStruct.item.cchTextMax = strlen(TStr.str());
	mTreeStruct.item.lParam = GetItemID();
	
	mTreeItemHandle = TreeCtrl.InsertItem(&mTreeStruct); 	

	TStr.rdbuf()->freeze(0);

	return mFileData.nFileSizeLow;
}

CString	DirEntry::GetName()
{
	return mDirName;
}

DirEntry::~DirEntry()
{
	int EntryCnt = mEntries.GetSize();
	int EntryOfst;

	for (EntryOfst = 0; EntryOfst < EntryCnt; EntryOfst++)
	{
		delete mEntries[EntryOfst];
	}

}

HTREEITEM	DirEntry::GetTreeItem()
{
	return mTreeItemHandle;
}

unsigned long DirEntry::Initialize(CTreeCtrl	&TreeCtrl)
{
	// tv_item
	WIN32_FIND_DATA 	*EntryData = new WIN32_FIND_DATA;
	int					EntryOfst;
	int					EntryCnt;
	HANDLE				FHandle;
	ostrstream			TStr;
	ostrstream			TStr2;
	TV_ITEM				TV_updater;


	TStr << mDirName << ends;
	TStr2 << GetFullPathName() << "\\*.*" << ends;
	
	
	// Get all names from this directory..
	FHandle = FindFirstFile(TStr2.str(),		// address of name of file to search for  
									EntryData );	// address of returned information 
									
									
		
	if (FHandle ==INVALID_HANDLE_VALUE)
	{
		assert(FALSE);
	}
	else
	{
		do
		{
			if(	(strcmp(EntryData->cFileName,"." ))
				&&	(strcmp(EntryData->cFileName,"..")) )
			{
				ostrstream			NewFullpath;

				NewFullpath << GetFullPathName() << "\\" << EntryData->cFileName << ends;

			   // if directory.. build new directory structure
				if (EntryData->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY )
		      {
		      	mEntries.Add(new DirEntry(	EntryData->cFileName,
														NewFullpath.str(),
														this						));
		      }
		      // else new file structure...
			   else 
				{
		      	mEntries.Add(new FileEntry(EntryData->cFileName,
														NewFullpath.str(),
														*EntryData,
														this						));
		      }
			
				NewFullpath.rdbuf()->freeze(0);
			}

		} while ( FindNextFile(	FHandle,		
										EntryData   ) );
	
		FindClose(FHandle);


		if(GetParent())
		{
			mTreeStruct.hParent = GetParent()->GetTreeItem();
		}
		else
		{
			mTreeStruct.hParent = NULL;
		}
		mTreeStruct.hInsertAfter = TVI_SORT;
		mTreeStruct.item.mask = TVIF_PARAM;
		mTreeStruct.item.lParam = GetItemID();
		
		mTreeItemHandle = TreeCtrl.InsertItem(&mTreeStruct); 	
		
		EntryCnt = mEntries.GetSize();

		for (EntryOfst = 0; EntryOfst < EntryCnt; EntryOfst++)
		{
			mAggregate_size += mEntries[EntryOfst]->Initialize(TreeCtrl);
		}
		ostrstream realOne;
      ostrstream numToFormat;
      ostrstream convertedNum;
      int numLen;
      int numOfst;

      numToFormat << mAggregate_size << ends;

      numLen = strlen(numToFormat.str());
      numOfst = numLen;

      while (numOfst > 0)
      {
         convertedNum << ((numToFormat.str())[numLen - numOfst]);
         if (     (((numOfst-1) % 3) == 0  )
               && ((numOfst-1) != 0        )   )
         {
            convertedNum << ",";
         }
         numOfst--;
      }
      convertedNum << ends;



		realOne << TStr.str() << "(" << convertedNum.str() << ")" << ends;

		TV_updater.mask = TVIF_TEXT | TVIF_HANDLE | TVIF_IMAGE  | TVIF_SELECTEDIMAGE;
      TV_updater.hItem = mTreeItemHandle;
		TV_updater.iImage = 1;
		TV_updater.iSelectedImage = 1;
		TV_updater.pszText = realOne.str();
		TV_updater.cchTextMax = strlen(realOne.str());
		TreeCtrl.SetItem(&TV_updater);

      realOne.rdbuf()->freeze(0);

      convertedNum.rdbuf()->freeze(0);
	}
	TStr2.rdbuf()->freeze(0);
	TStr.rdbuf()->freeze(0);

	delete EntryData;

   return mAggregate_size;

}
void DirEntry::ChangeImageTo(	CTreeCtrl		&TreeCtrl,
										unsigned int 	Image,
										unsigned int	SelectedImage)
{
	TV_ITEM				TV_updater;

	TV_updater.mask = TVIF_HANDLE | TVIF_IMAGE | TVIF_SELECTEDIMAGE;
   TV_updater.hItem = mTreeItemHandle;
	TV_updater.iImage = Image;
	TV_updater.iSelectedImage = SelectedImage;

	TreeCtrl.SetItem(&TV_updater);
}

void DirEntry::ChangeImage(CTreeCtrl	&TreeCtrl)
{
	int					EntryOfst;
	int					EntryCnt = mEntries.GetSize();

	ChangeImageTo(TreeCtrl,2,1);

	for (EntryOfst = 0; EntryOfst < EntryCnt; EntryOfst++)
	{
		mEntries[EntryOfst]->ChangeImage(TreeCtrl);
	}
}

void DirEntry::ChangeImageBack(CTreeCtrl	&TreeCtrl)
{
	int					EntryOfst;
	int					EntryCnt = mEntries.GetSize();

	ChangeImageTo(TreeCtrl,1,2);

	for (EntryOfst = 0; EntryOfst < EntryCnt; EntryOfst++)
	{
		mEntries[EntryOfst]->ChangeImageBack(TreeCtrl);
	}
}


void DirEntry::PrintInfo()
{

}


