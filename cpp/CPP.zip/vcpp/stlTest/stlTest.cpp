#include <iostream.h>
#include <vector>

void main()
{

   std::vector<int>           intVec;
   std::vector<int>::iterator intVecIter;


   intVec.push_back(10);
   intVec.push_back(9);
   intVec.push_back(8);
   intVec.push_back(7);


   for ( intVecIter  = intVec.begin();
         intVecIter != intVec.end();
         intVecIter++)
   {
      cout << *intVecIter << " ";
   }
   cout << endl;

}