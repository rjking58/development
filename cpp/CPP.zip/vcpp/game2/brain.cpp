// #include <stdafx.h>
#include "brain.h"

