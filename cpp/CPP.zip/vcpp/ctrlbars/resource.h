//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ctrlbars.rc
//
#define IDB_STYLES                      3
#define IDD_ABOUTBOX                    100
#define IDC_PALETTE                     101
#define IDW_COMBO                       102
#define IDD_VIEWSELECT                  102
#define IDS_DEFAULT_FONT                103
#define IDB_PALETTE                     106
#define IDR_MAINFRAME                   128
#define IDW_STYLES                      501
#define IDM_VIEWPALETTE                 502
#define ID_PALETTE_BASE                 601
#define ID_PALETTEERASE                 601
#define ID_PALETTEPEN                   602
#define ID_PALETTESELECT                603
#define ID_PALETTEBRUSH                 604
#define ID_PALETTESPRAY                 605
#define ID_PALETTEPAINT                 606
#define ID_PALETTELINE                  607
#define ID_PALETTEEYEDROP               608
#define ID_PALETTEMAG                   609
#define ID_PALETTERECT                  610
#define ID_PALETTEROUND                 611
#define ID_PALETTEOVAL                  612
#define ID_VIEW_DLGBARTOP               32800
#define ID_VIEW_SHORT                   32801
#define ID_VIEW_LONG                    32802
#define ID_TOGGLE_INSERT                32803
#define IDM_PALETTE_2COLUMN             32804
#define IDM_PALETTE_3COLUMN             32805
#define ID_STYLE_BASE                   33000
#define ID_STYLE_LEFT                   33000
#define ID_STYLE_CENTERED               33001
#define ID_STYLE_RIGHT                  33002
#define ID_STYLE_JUSTIFIED              33003
#define ID_PALETTEBAR                   59396
#define IDS_LEFT                        61204
#define IDS_RIGHT                       61205
#define IDS_CENTERED                    61206
#define IDS_JUSTIFIED                   61207
#define IDS_SELECTED_PROMPT             61208

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         34000
#define _APS_NEXT_CONTROL_VALUE         105
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
