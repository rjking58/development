
#include "stdafx.h"
#include "mixcpu.h"

ArithmeticRegister::ArithmeticRegister()
{
	int x = 0;

	x = 1;
}
