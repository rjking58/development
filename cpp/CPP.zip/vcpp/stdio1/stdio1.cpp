#include <stdio.h>
#include <afxwin.h>		 // MFC core and standard components
#include <afxext.h>         // MFC extensions (including VB)
#include <afxtempl.h>


void main(void)
{
	int a;

	a = 1;
	//printf ("abc");
}