//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by INI1.RC
//
#define IDR_MAINFRAME				128
#define IDR_INI1TYPE				129
#define IDR_INI1TYPE_CNTR_IP		6
#define IDD_ABOUTBOX				100
#define IDP_OLE_INIT_FAILED			100
#define IDP_FAILED_TO_CREATE		102
#define ID_CANCEL_EDIT_CNTR			32768

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS			1
#define _APS_NEXT_RESOURCE_VALUE	130
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		101
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
