/*
	 +--------------------------------------------------------------------+
	 | Copyright (c) 1993 Treasury Services Corp  ALL RIGHTS RESERVED     |
	 +--------------------------------------------------------------------+
*/
#include <compatNT.h>
#include <windows.h>
#include <string.h>
#include <scramble.h>

// 
// @DESC: BP standalone encryption library.
// 		 
// 		 
// @PGMR: RJK
// @CRDT: 980504	.. two digit year... whee!!

extern "C" void _export FAR PASCAL EncryptPassword( LPSTR Password, LPSTR EncryptedPassword );



int FAR PASCAL LibMain(	HINSTANCE	/* hInstance */, 
								WORD 			/*wDataSeg*/,
								WORD 			/* cbHeapSize */, 
								LPSTR 		/*lpCmdLine */ 	)
{
	
	return 1;
}

int FAR PASCAL WEP ( int /*bSystemExit*/ )
{

	return 1;
}


extern "C" void _export FAR PASCAL EncryptPassword( LPSTR Password, LPSTR EncryptedPassword )
{
	convertPassword( Password, EncryptedPassword );
}
