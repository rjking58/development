/*------------------------------------------------------------------------*/
/*                                                                        */
/*  B32ARRAYS.H                                                              */
/*                                                                        */
/*  Copyright Borland International 1991, 1992                            */
/*  All Rights Reserved                                                   */
/*                                                                        */
/*------------------------------------------------------------------------*/

#if !defined( __B32ARRAYS_H )
#define __B32ARRAYS_H


#define TEMPLATES

#if !defined( __DEFS_H )
#include <_defs.h>
#endif  // __DEFS_H

#if !defined( __RESOURCE_H )
#include <resource.h>
#endif  // __RESOURCE_H

#if !defined( __COLLECT_H )
#include <collect.h>
#endif  // __COLLECT_H

#if !defined( __MEM_H )
#include <mem.h>
#endif  // __MEM_H

#if !defined( __B32VECTIMP_H )
#include <bi32vectimp.h>
#endif  // __B32VECTIMP_H

#if !defined( __SORTABLE_H )
#include <sortable.h>
#endif  // __SORTABLE_H

#if !defined( __ABSTARRY_H )
#include <abstarry.h>
#endif  // __ABSTARRY_H

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class Vect, class T> class BI32_ArrayAsVectorImp              */
/*                                                                        */
/*  Implements the fundamental array operations, using a vector           */
/*  as the underlying implementation.  The type Vect specifies the        */
/*  form of the vector, either a BI32_CVectorImp<T0> or a                   */
/*  BI32_IVectorImp<T0>.  The type T specifies the type of the              */
/*  objects to be put in the array.  When using BI32_CVectorImp<T0>,        */
/*  T should be the same as T0. When using BI32_ICVectorImp<T0>, T          */
/*  should be of type pointer to T0.  See BI32_ArrayAsVector and            */
/*  BI32_IArrayAsVector for examples.                                       */
/*                                                                        */
/*------------------------------------------------------------------------*/

template <class Vect, class T>
class _CLASSTYPE BI32_ArrayAsVectorImp
{

public:

    BI32_ArrayAsVectorImp( long upper, long lower, long delta ) :
        data( upper-lower+1,delta),
        lowerbound(lower)
        {
        }

    long lowerBound() const
        {
        return lowerbound;
        }

    long upperBound() const
        {
        return boundBase(data.limit())-1;
        }

    sizeType arraySize() const
        {
        return data.limit();
        }

    void add( T t )
        {
        data.add( t );
        }

    void addAt( T t, long loc )
        {
        data.addAt( t, zeroBase(loc) );
        }

    void FindAndDetach( T t, TShouldDelete::DeleteType dt = TShouldDelete::NoDelete )
        {
        data.FindAndDetach( t, dt );
        }

    void detach( long loc,
                 TShouldDelete::DeleteType dt =TShouldDelete::NoDelete
               )
        {
        data.detach( zeroBase(loc), dt );
        }

    void destroy( long i )
        {
        detach( i, TShouldDelete::Delete );
        }

    void flush( TShouldDelete::DeleteType dt = TShouldDelete::DefDelete )
        {
        data.flush( dt );
        }

    int isFull() const
        {
        return data.getDelta() == 0 && data.count() >= data.limit();
        }

    int hasMember( T t ) const
        {
        return data.find(t) != ULONG_MAX;
        }

    int isEmpty() const
        {
        return data.count() == 0;
        }

    countType getItemsInContainer() const
        {
        return data.count();
        }


    T itemAt( long i ) const
        {
        return data[ zeroBase(i) ];
        }

    unsigned long find( const T t ) const
        {
        return boundBase(data.find( t ));
        }

    void reallocate( sizeType sz, sizeType offset = 0 )
        {
        data.resize( sz, offset );
        }


    void setData( long loc, T t )
        {
        PRECONDITION( loc >= lowerbound && loc <= upperBound() );
        data[ zeroBase(loc) ] = t;
        }

    void insertEntry( long loc )
        {
        PRECONDITION( loc >= lowerbound && loc <= upperBound() );
        T t;
        data.addAt( t, zeroBase(loc) );
        }

    void removeEntry( long loc )
        {
        squeezeEntry( zeroBase(loc) );
        }

    void squeezeEntry( unsigned long loc )
        {
        PRECONDITION( loc < data.count() );
        data.detach( loc );
        }

    unsigned long zeroBase( long loc ) const
        {
        return loc - lowerbound;
        }

    long boundBase( unsigned long loc ) const
        {
        return loc == ULONG_MAX ? LONG_MAX : loc + lowerbound;
        }

    void grow( long loc )
        {
        if( loc < lowerBound() )
            reallocate( arraySize() + (loc - lowerbound) );
        else if( loc >= boundBase(data.limit()) )
            reallocate( zeroBase(loc) );
        }

    long lowerbound;

    Vect data;

};

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class T> class BI32_ArrayAsVector                             */
/*                                                                        */
/*  Implements an array of objects of type T, using a vector as           */
/*  the underlying implementation.                                        */
/*                                                                        */
/*------------------------------------------------------------------------*/

template <class T> class _CLASSTYPE BI32_ArrayAsVector :
    public BI32_ArrayAsVectorImp<BI32_CVectorImp<T>,T>
{

public:

    //iend class _CLASSTYPE BI32_ArrayAsVectorIterator<T>;

    BI32_ArrayAsVector( long upper, long lower = 0, long delta = 0 ) :
        BI32_ArrayAsVectorImp<BI32_CVectorImp<T>,T>( upper, lower, delta )
        {
        }

    T& operator []( long loc )
        {
        grow( loc+1 );
        return data[zeroBase(loc)];
        }

    T& operator []( long loc ) const
        {
        PRECONDITION( loc >= lowerbound && (unsigned long) loc < data.count() );
        return data[zeroBase(loc)];
        }

    void forEach( void ( *f)(T  &, void  *), void  *args )
        {
        if( !isEmpty() )
            data.forEach( f, args );
        }

    T  *firstThat( int ( *f)(const T  &, void  *),
                       void  *args
                     ) const
        {
        if( isEmpty() )
            return 0;
        return data.firstThat( f, args );
        }

    T  *lastThat( int ( * f)(const T  &, void  *),
                      void  *args
                    ) const
        {
        if( isEmpty() )
            return 0;
        return data.lastThat( f, args );
        }

};

template <class T> class _CLASSTYPE BI32_ArrayAsVectorIterator :
    public BI32_VectorIteratorImp<T>
{

public:

    BI32_ArrayAsVectorIterator( const BI32_ArrayAsVector<T>  & a ) :
        BI32_VectorIteratorImp<T>(a.data) {}

};

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class T> class BI32_IArrayAsVector                            */
/*                                                                        */
/*  Implements an indirect array of objects of type T, using a vector as  */
/*  the underlying implementation.                                        */
/*                                                                        */
/*------------------------------------------------------------------------*/

template <class T> class _CLASSTYPE BI32_IArrayAsVector :
    public BI32_ArrayAsVectorImp<BI32_ICVectorImp<T>,T  *>,
    public virtual TShouldDelete
{

public:

    //iend class _CLASSTYPE BI32_IArrayAsVectorIterator<T>;

    BI32_IArrayAsVector( long upper, long lower = 0, long delta = 0 ) :
        BI32_ArrayAsVectorImp<BI32_ICVectorImp<T>,T  *>( upper, lower, delta )
        {
        }

    ~BI32_IArrayAsVector()
        {
        flush();
        }

    T  *  & operator []( long loc )
        {
        grow( loc+1 );
        return data[zeroBase(loc)];
        }

    T  *  operator []( long loc ) const
        {
        PRECONDITION( loc >= lowerbound && zeroBase(loc) < data.limit() );
        return data[zeroBase(loc)];
        }

    void add( T  *t )
        {
        BI32_ArrayAsVectorImp<BI32_ICVectorImp<T>,T  *>::add(t);
        }

    void addAt( T  *t, long loc )
        {
        BI32_ArrayAsVectorImp<BI32_ICVectorImp<T>,T  *>::addAt(t,loc);
        }

    void detach( long loc, DeleteType dt = NoDelete )
        {
        data.detach( zeroBase(loc), delObj(dt) );
        }

    void FindAndDetach( T  *t, DeleteType dt = NoDelete )
        {
        unsigned long loc = data.find( t );
        if( loc == ULONG_MAX )
            return;
        data.detach( loc, delObj(dt) );
        }

    void flush( DeleteType dt = DefDelete )
        {
        data.flush( delObj(dt), data.limit(), 0 );
        }

    unsigned long find( const T *t ) const
        {
        return boundBase(data.find( (T *)t ));
        }

    void forEach( void ( *f)(T  &, void  *), void  *args )
        {
        if( !isEmpty() )
            data.forEach( f, args );
        }

    T  *firstThat( int ( *f)(const T  &, void  *),
                       void  *args
                     ) const
        {
        if( isEmpty() )
            return 0;
        return data.firstThat( f, args );
        }

    T  *lastThat( int ( * f)(const T  &, void  *),
                      void  *args
                    ) const
        {
        if( isEmpty() )
            return 0;
        return data.lastThat( f, args );
        }

};

template <class T> class _CLASSTYPE BI32_IArrayAsVectorIterator :
    public BI32_IVectorIteratorImp<T>
{

public:

    BI32_IArrayAsVectorIterator( const BI32_IArrayAsVector<T>  &a ) :
        BI32_IVectorIteratorImp<T>(a.data) {}

};

#ifdef BC_OBJECTS
/*------------------------------------------------------------------------*/
/*                                                                        */
/*  class BI32_OArrayAsVector                                               */
/*                                                                        */
/*  Implements an array of pointers to Object,                            */
/*  using a vector as the underlying implementation.                      */
/*                                                                        */
/*------------------------------------------------------------------------*/

class _CLASSTYPE BI32_OArrayAsVector
{

public:

    //iend class _CLASSTYPE BI32_OArrayAsVectorIterator;

    BI32_OArrayAsVector() : oarray( DEFAULT_ARRAY_SIZE )
        {
        }

    BI32_OArrayAsVector( long upr, long lwr = 0, unsigned long delta = 0 ) :
        oarray( upr, lwr, delta )
        {
        }

    Object *operator [] (long loc)
        {
        return oarray[loc];
        }

    Object *operator [] (long loc) const
        {
        return oarray[loc];
        }

    long lowerBound() const
        {
        return oarray.lowerBound();
        }

    long upperBound() const
        {
        return oarray.upperBound();
        }

    sizeType arraySize() const
        {
        return oarray.arraySize();
        }

    void add( Object  *o )
        {
        oarray.add(o);
        }

    void addAt( Object  *o, long loc )
        {
        oarray.addAt(o,loc);
        }

    void detach( long loc,
                 TShouldDelete::DeleteType dt = TShouldDelete::NoDelete
               )
        {
        oarray.detach( loc, dt );
        }

    void FindAndDetach( Object  *o,
                 TShouldDelete::DeleteType dt = TShouldDelete::NoDelete
               )
        {
        oarray.FindAndDetach( o, dt );
        }

    void destroy( long i )
        {
        oarray.destroy( i );
        }

    void flush( TShouldDelete::DeleteType dt = TShouldDelete::DefDelete )
        {
        oarray.flush( dt );
        }

    int hasMember( Object  *o ) const
        {
        return oarray.hasMember(o);
        }

    Object  *findMember( Object  *o ) const
        {
        long loc = oarray.find(o);
        return loc != LONG_MAX ? oarray[loc] : 0;
        }

    int isEmpty() const
        {
        return oarray.isEmpty();
        }

    int isFull() const
        {
        return oarray.isFull();
        }

    void forEach( void (*f)(Object  &, void *), void *args )
        {
        oarray.forEach( f, args );
        }

    Object  *firstThat( int ( *f)(const Object  &, void  *),
                            void  *args
                          ) const
        {
        return oarray.firstThat( f, args );
        }

    Object  *lastThat( int ( *f)(const Object  &, void  *),
                           void  *args
                         ) const
        {
        return oarray.lastThat( f, args );
        }

    long getItemsInContainer() const
        {
        return oarray.getItemsInContainer();
        }

    int ownsElements()
        {
        return oarray.ownsElements();
        }

    void ownsElements( int del )
        {
        oarray.ownsElements( del );
        }


    BI32_IArrayAsVector<Object> oarray;

};

class _CLASSTYPE BI32_OArrayAsVectorIterator :
    public BI32_IArrayAsVectorIterator<Object>
{

public:

    BI32_OArrayAsVectorIterator( const BI32_OArrayAsVector  &a ) :
        BI32_IArrayAsVectorIterator<Object>(a.oarray)
        {
        restart();
        }

    void restart()
        {
        BI32_IArrayAsVectorIterator<Object>::restart();
        if( current() == 0 )
            (*this)++;
        }

};

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  class BI32_TCArrayAsVector                                              */
/*                                                                        */
/*  Implements an Object array, with the full semantics of                */
/*  the BC 2.0 style array, using a vector as the underlying              */
/*  implementation.                                                       */
/*                                                                        */
/*------------------------------------------------------------------------*/

class _CLASSTYPE BI32_TCArrayAsVector : public AbstractArray
{

public:


    BI32_TCArrayAsVector( long upper, long lower = 0, sizeType delta = 0 ) :
        array( upper, lower, delta )
        {
        }

    virtual Object& operator []( long loc )
        {
        return ptrToRef(array[loc]);
        }

    virtual Object& operator []( long loc ) const
        {
        return ptrToRef(array[loc]);
        }

    virtual long lowerBound() const
        {
        return array.lowerBound();
        }

    virtual long upperBound() const
        {
        return array.upperBound();
        }

    virtual sizeType arraySize() const
        {
        return array.arraySize();
        }

    void add( Object  &o )
        {
        array.add(&o);
        }

    void addAt( Object  &o, long loc )
        {
        array.addAt(&o,loc);
        }

    virtual void detach( long loc, DeleteType dt = NoDelete )
        {
        array.detach( loc, dt );
        }

    void FindAndDetach( Object  &o,
                 TShouldDelete::DeleteType dt = TShouldDelete::NoDelete
               )
        {
        array.FindAndDetach( &o, dt );
        }

    void flush( TShouldDelete::DeleteType dt = TShouldDelete::DefDelete )
        {
        array.flush( dt );
        }

    int hasMember( Object  &o ) const
        {
        return array.hasMember(&o);
        }

    Object  &findMember( Object  &o ) const
        {
        return ptrToRef(array.findMember(&o));
        }

    int isEmpty() const
        {
        return array.isEmpty();
        }

    long isFull() const
        {
        return array.isFull();
        }

    void forEach( void (*f)(Object  &, void *), void *args )
        {
        array.forEach( f, args );
        }

    Object  &firstThat( int ( *f)(const Object  &, void  *),
                            void  *args
                          ) const
        {
        return ptrToRef(array.firstThat( f, args ));
        }

    Object  &lastThat( int ( *f)(const Object  &, void  *),
                           void  *args
                         ) const
        {
        return ptrToRef(array.lastThat( f, args ));
        }

    long getItemsInContainer() const
        {
        return array.getItemsInContainer();
        }

    virtual classType isA() const
        {
        return arrayClass;
        }

    virtual char  *nameOf() const
        {
        return "BI32_TCArrayAsVector";
        }

    int ownsElements()
        {
        return array.ownsElements();
        }

    void ownsElements( int del )
        {
        array.ownsElements( del );
        }

    ContainerIterator  &initIterator() const;


    BI32_OArrayAsVector array;

};

class _CLASSTYPE BI32_TCArrayAsVectorIterator : public ContainerIterator
{

public:

    BI32_TCArrayAsVectorIterator( const BI32_TCArrayAsVector  &a ) :
        iter(a.array)
        {
        }

    virtual operator int()
        {
        return int(iter);
        }

    virtual Object  & current()
        {
        return Object::ptrToRef(iter.current());
        }

    virtual Object  & operator ++ ( long )
        {
        return Object::ptrToRef(iter++);
        }

    virtual Object  & operator ++ ()
        {
        return Object::ptrToRef(++iter);
        }

    virtual void restart()
        {
        iter.restart();
        }

//ivate:

    BI32_OArrayAsVectorIterator iter;

};

inline ContainerIterator  & BI32_TCArrayAsVector::initIterator() const
        { return *new BI32_TCArrayAsVectorIterator( *this ); }
#endif // BC_OBJECTS

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class T> class BI32_SArrayAsVector                            */
/*                                                                        */
/*  Implements a sorted array of objects of type T, using a vector as     */
/*  the underlying implementation.                                        */
/*                                                                        */
/*------------------------------------------------------------------------*/

template <class T> class _CLASSTYPE BI32_SArrayAsVector :
    public BI32_ArrayAsVectorImp<BI32_SVectorImp<T>,T>
{

public:


    BI32_SArrayAsVector( long upper, long lower = 0, long delta = 0 ) :
        BI32_ArrayAsVectorImp<BI32_SVectorImp<T>,T>( upper, lower, delta )
        {
        }

    T& operator []( long loc )
        {
        grow( loc+1 );
        return data[zeroBase(loc)];
        }

    T& operator []( long loc ) const
        {
        PRECONDITION( loc >= lowerbound && (unsigned long)loc < data.count() );
        return data[zeroBase(loc)];
        }

    void forEach( void ( *f)(T  &, void  *), void  *args )
        {
        if( !isEmpty() )
            data.forEach( f, args );
        }

    T  *firstThat( int ( *f)(const T  &, void  *),
                       void  *args
                     ) const
        {
        if( isEmpty() )
            return 0;
        return data.firstThat( f, args );
        }

    T  *lastThat( int ( * f)(const T  &, void  *),
                      void  *args
                    ) const
        {
        if( isEmpty() )
            return 0;
        return data.lastThat( f, args );
        }

};

template <class T> class _CLASSTYPE BI32_SArrayAsVectorIterator :
    public BI32_VectorIteratorImp<T>
{

public:

    BI32_SArrayAsVectorIterator( const BI32_SArrayAsVector<T>  & a ) :
        BI32_VectorIteratorImp<T>(a.data) {}

};

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class T> class BI32_ISArrayAsVector                           */
/*                                                                        */
/*  Implements an indirect sorted array of objects of type T, using a     */
/*  vector as the underlying implementation.                              */
/*                                                                        */
/*------------------------------------------------------------------------*/

template <class T> class _CLASSTYPE BI32_ISArrayAsVector :
    public BI32_ArrayAsVectorImp<BI32_ISVectorImp<T>,T  *>,
    public virtual TShouldDelete
{

public:

    //iend class _CLASSTYPE BI32_ISArrayAsVectorIterator<T>;

    BI32_ISArrayAsVector( long upper, long lower = 0, long delta = 0 ) :
        BI32_ArrayAsVectorImp<BI32_ISVectorImp<T>,T *>( upper, lower, delta )
        {
        }

    ~BI32_ISArrayAsVector()
        {
        flush();
        }

    T  *  & operator []( long loc )
        {
        grow( loc+1 );
        return data[zeroBase(loc)];
        }

	 T  *  operator []( long loc ) const
        {
        PRECONDITION( loc >= lowerbound && (unsigned long) loc < data.count());
        return data[zeroBase(loc)];
        }

    void add( T  *t )
        {
        BI32_ArrayAsVectorImp<BI32_ISVectorImp<T>,T  *>::add(t);
        }

    void addAt( T  *t, long loc )
        {
        BI32_ArrayAsVectorImp<BI32_ISVectorImp<T>,T  *>::addAt(t,loc);
        }

    void detach( long loc, DeleteType dt = NoDelete )
        {
        data.detach( loc, delObj(dt) );
        }

    void FindAndDetach( T  *t, DeleteType dt = NoDelete )
        {
        unsigned long loc = data.find( t );
        if( loc == ULONG_MAX )
            return;
        data.detach( loc, delObj(dt) );
        }

    void flush( DeleteType dt = DefDelete )
        {
        data.flush( delObj(dt), data.limit(), 0 );
        }

    unsigned long find( const T *t ) const
        {
        return boundBase( data.find( (T *)t ) );
        }

    void forEach( void ( *f)(T  &, void  *), void  *args )
        {
        if( !isEmpty() )
            data.forEach( f, args );
        }

    T  *firstThat( int ( *f)(const T  &, void  *),
                       void  *args
                     ) const
        {
        if( isEmpty() )
            return 0;
        return data.firstThat( f, args );
        }

    T  *lastThat( int ( * f)(const T  &, void  *),
                      void  *args
                    ) const
        {
        if( isEmpty() )
            return 0;
        return data.lastThat( f, args );
        }

};

template <class T> class _CLASSTYPE BI32_ISArrayAsVectorIterator :
    public BI32_IVectorIteratorImp<T>
{

public:

    BI32_ISArrayAsVectorIterator( const BI32_ISArrayAsVector<T>  &a ) :
        BI32_IVectorIteratorImp<T>(a.data) {}

};

#ifdef BC_OBJECTS
/*------------------------------------------------------------------------*/
/*                                                                        */
/*  class BI32_ISObjectVector                                               */
/*                                                                        */
/*  Implements a sorted vector of pointers to Object.                     */
/*  This is implemented through the template BI32_ISVectorImp<Object>.      */
/*                                                                        */
/*------------------------------------------------------------------------*/

class _CLASSTYPE BI32_ISObjectVector :
    public BI32_InternalIVectorImp<Object, BI32_ISVectorImp<void  *> >
{

public:

    BI32_ISObjectVector( unsigned long sz, unsigned long d = 0 ) :
        BI32_InternalIVectorImp<Object, BI32_ISVectorImp<void  *> >(sz)
        {
        delta = d;
        }

    ~BI32_ISObjectVector()
        {
        flush();
        }

    void add( Object  *o );

    void addAt( Object  *t, unsigned long loc )
        {
        BI32_InternalIVectorImp<Object, BI32_ISVectorImp<void  *> >::addAt(t,loc);
        }

    void detach( unsigned long loc, int del = 0 )
        {
        BI32_InternalIVectorImp<Object, BI32_ISVectorImp<void  *> >::detach( loc, del );
        }

    void FindAndDetach( Object  *t, int del = 0 )
        {
        unsigned long loc = find( t );
        if( loc == ULONG_MAX )
            return;
        BI32_InternalIVectorImp<Object, BI32_ISVectorImp<void  *> >::detach( loc, del );
        }

    void flush( int del = 0 )
        {
        BI32_InternalIVectorImp<Object, BI32_ISVectorImp<void  *> >::flush( del );
        }

    unsigned long find( Object  *t ) const
        {
        return find( (void  *)t );
        }


    unsigned long find( void  *t ) const;


    virtual void removeData( void  *t )
        {
        delete (Object  *)t;
        }

};

class _CLASSTYPE BI32_ISObjectVectorIterator :
    public BI32_IVectorIteratorImp<Object>
{

public:

    BI32_ISObjectVectorIterator( const BI32_ISObjectVector  &a ) :
        BI32_IVectorIteratorImp<Object>(a) {}

};

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  class BI32_ISObjectArray                                                */
/*                                                                        */
/*  Implements an indirect sorted array of pointers to Object, using a    */
/*  vector as the underlying implementation.                              */
/*                                                                        */
/*------------------------------------------------------------------------*/

class _CLASSTYPE BI32_ISObjectArray :
    public BI32_ArrayAsVectorImp<BI32_ISObjectVector,Object  *>,
    public virtual TShouldDelete
{

public:

    //iend class _CLASSTYPE BI32_ISObjectArrayIterator;

    BI32_ISObjectArray( long upr, long lwr = 0, long delta = 0 ) :
        BI32_ArrayAsVectorImp<BI32_ISObjectVector,Object *>( upr, lwr, delta )
        {
        }

    ~BI32_ISObjectArray()
        {
        flush();
        }

    Object  *  & operator []( long loc )
        {
        grow( loc+1 );
        return data[zeroBase(loc)];
        }

    Object  *  & operator []( long loc ) const
        {
        PRECONDITION( loc >= lowerbound && zeroBase(loc) < data.count() );
        return data[zeroBase(loc)];
        }

    void add( Object  *t )
        {
        BI32_ArrayAsVectorImp<BI32_ISObjectVector,Object  *>::add(t);
        }

    void addAt( Object  *t, long loc )
        {
        BI32_ArrayAsVectorImp<BI32_ISObjectVector,Object  *>::addAt(t,loc);
        }

    void detach( long loc, DeleteType dt = NoDelete )
        {
        data.detach( zeroBase(loc), delObj(dt) );
        }

    void FindAndDetach( Object  *t, DeleteType dt = NoDelete )
        {
        data.FindAndDetach( t, delObj(dt) );
        }

    void flush( DeleteType dt = DefDelete )
        {
        data.flush( delObj(dt) );
        }

    unsigned long find( const Object *t ) const
        {
        return boundBase(data.find( (Object *)t ));
        }

    void forEach( void (*f)(Object  &, void *), void *args )
        {
        if( !isEmpty() )
            data.forEach( f, args );
        }

    Object  *firstThat( int ( *f)(const Object  &, void  *),
                            void  *args
                          ) const
        {
        if( isEmpty() )
            return 0;
        return data.firstThat( f, args );
        }

    Object  *lastThat( int ( * f)(const Object  &, void  *),
                           void  *args
                         ) const
        {
        if( isEmpty() )
            return 0;
        return data.lastThat( f, args );
        }

};

class _CLASSTYPE BI32_ISObjectArrayIterator :
    public BI32_ISObjectVectorIterator
{

public:

    BI32_ISObjectArrayIterator( const BI32_ISObjectArray  &a ) :
        BI32_ISObjectVectorIterator(a.data) {}

};

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  class BI32_OSArrayAsVector                                              */
/*                                                                        */
/*  Implements a sorted array of pointers to Object,                      */
/*  using a vector as the underlying implementation.                      */
/*                                                                        */
/*  Although the interface is written to take pointers to Object, in      */
/*  fact, pointers to Sortable are required.                              */
/*                                                                        */
/*------------------------------------------------------------------------*/

class _CLASSTYPE BI32_OSArrayAsVector
{

public:

    //iend class _CLASSTYPE BI32_OSArrayAsVectorIterator;

    BI32_OSArrayAsVector() : oarray( DEFAULT_ARRAY_SIZE, 0, 0 )
        {
        }

    BI32_OSArrayAsVector( long upr, long lwr = 0, unsigned long delta = 0 ) :
        oarray( upr, lwr, delta )
        {
        }

    Object *operator [] (long loc)
        {
        return oarray[loc];
        }

    Object *operator [] (long loc) const
        {
        return oarray[loc];
        }

    long lowerBound() const
        {
        return oarray.lowerBound();
        }

    long upperBound() const
        {
        return oarray.upperBound();
        }

    sizeType arraySize() const
        {
        return oarray.arraySize();
        }

    void add( Object  *o )
        {
        PRECONDITION( o->isSortable() );
        oarray.add(o);
        }

    void addAt( Object  *o, long loc )
        {
        PRECONDITION( o->isSortable() );
        oarray.addAt(o,loc);
        }

    void detach( long loc,
                 TShouldDelete::DeleteType dt = TShouldDelete::NoDelete
               )
        {
        oarray.detach( loc, dt );
        }

    void FindAndDetach( Object  *o,
                 TShouldDelete::DeleteType dt = TShouldDelete::NoDelete
               )
        {
        PRECONDITION( o->isSortable() );
        oarray.FindAndDetach( o, dt );
        }

    void flush( TShouldDelete::DeleteType dt = TShouldDelete::DefDelete )
        {
        oarray.flush( dt );
        }

    int hasMember( Object  *o ) const
        {
        PRECONDITION( o->isSortable() );
        return oarray.hasMember(o);
        }

    Object  *findMember( Object  *o ) const
        {
        PRECONDITION( o->isSortable() );
        long loc = oarray.find(o);
        return loc != LONG_MAX ? oarray[loc] : 0;
        }

    int isEmpty() const
        {
        return oarray.isEmpty();
        }

    int isFull() const
        {
        return oarray.isFull();
        }

    void forEach( void (*f)(Object  &, void *), void *args )
        {
        oarray.forEach( f, args );
        }

    Object  *firstThat( int ( *f)(const Object  &, void  *),
                            void  *args
                          ) const
        {
        return oarray.firstThat( f, args );
        }

    Object  *lastThat( int ( *f)(const Object  &, void  *),
                           void  *args
                         ) const
        {
        return oarray.lastThat( f, args );
        }

    long getItemsInContainer() const
        {
        return oarray.getItemsInContainer();
        }

    int ownsElements()
        {
        return oarray.ownsElements();
        }

    void ownsElements( int del )
        {
        oarray.ownsElements( del );
        }

//otected:

    BI32_ISObjectArray oarray;

};

class _CLASSTYPE BI32_OSArrayAsVectorIterator :
    public BI32_ISObjectArrayIterator
{

public:

    BI32_OSArrayAsVectorIterator( const BI32_OSArrayAsVector  &a ) :
        BI32_ISObjectArrayIterator(a.oarray)
        {
        }

};

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  class BI32_TCSArrayAsVector                                             */
/*                                                                        */
/*  Implements a sorted Object array, with the full semantics of          */
/*  the BC 2.0 style sorted array, using a vector as the underlying       */
/*  implementation.                                                       */
/*                                                                        */
/*------------------------------------------------------------------------*/

class _CLASSTYPE BI32_TCSArrayAsVector : public AbstractArray
{

public:


    BI32_TCSArrayAsVector( long upper = DEFAULT_ARRAY_SIZE,
                         long lower = 0,
                         sizeType delta = 0
                       ) :
        array( upper, lower, delta )
        {
        }

    virtual Object& operator []( long loc )
        {
        return ptrToRef(array[loc]);
        }

    virtual Object& operator []( long loc ) const
        {
        return ptrToRef(array[loc]);
        }

    virtual long lowerBound() const
        {
        return array.lowerBound();
        }

    virtual long upperBound() const
        {
        return array.upperBound();
        }

    virtual sizeType arraySize() const
        {
        return array.arraySize();
        }

    void add( Object  &o )
        {
        array.add(&o);
        }

    void addAt( Object  &o, long loc )
        {
        array.addAt(&o,loc);
        }

    virtual void detach( long loc, DeleteType dt = NoDelete )
        {
        array.detach( loc, dt );
        }

    void FindAndDetach( Object  &o, DeleteType dt = NoDelete )
        {
        array.FindAndDetach( &o, dt );
        }

    void flush( TShouldDelete::DeleteType dt = DefDelete )
        {
        array.flush( dt );
        }

    int hasMember( Object  &o ) const
        {
        return array.hasMember(&o);
        }

    Object  &findMember( Object  &o ) const
        {
        return ptrToRef(array.findMember(&o));
        }

    int isEmpty() const
        {
        return array.isEmpty();
        }

    int isFull() const
        {
        return array.isFull();
        }

    void forEach( void (*f)(Object  &, void *), void *args )
        {
        array.forEach( f, args );
        }

    Object  &firstThat( int ( *f)(const Object  &, void  *),
                            void  *args
                          ) const
        {
        return ptrToRef(array.firstThat( f, args ));
        }

    Object  &lastThat( int ( *f)(const Object  &, void  *),
                           void  *args
                         ) const
        {
        return ptrToRef(array.lastThat( f, args ));
        }

    long getItemsInContainer() const
        {
        return array.getItemsInContainer();
        }

    virtual classType isA() const
        {
        return sortedArrayClass;
        }

    virtual char  *nameOf() const
        {
        return "BI32_TCSArrayAsVector";
        }

    int ownsElements()
        {
        return array.ownsElements();
        }

    void ownsElements( int del )
        {
        array.ownsElements( del );
        }

    ContainerIterator  & initIterator() const;


    BI32_OSArrayAsVector array;

};

class _CLASSTYPE BI32_TCSArrayAsVectorIterator : public ContainerIterator
{

public:

    BI32_TCSArrayAsVectorIterator( const BI32_TCSArrayAsVector  &a ) :
        iter(a.array)
        {
        }

    virtual operator int()
        {
        return int(iter);
        }

    virtual Object  & current()
        {
        return Object::ptrToRef(iter.current());
        }

    virtual Object  & operator ++ ( int )
        {
        return Object::ptrToRef(iter++);
        }

    virtual Object  & operator ++ ()
        {
        return Object::ptrToRef(++iter);
        }

    virtual void restart()
        {
        iter.restart();
        }


    BI32_OSArrayAsVectorIterator iter;

};

inline ContainerIterator  & BI32_TCSArrayAsVector::initIterator() const
        {
        return *new BI32_TCSArrayAsVectorIterator( *this );
        }

#endif // BC_OBJECTS

#endif  // __B32ARRAYS_H

