/*------------------------------------------------------------------------*/
/*                                                                        */
/*  B32VECTIMP.H                                                             */
/*                                                                        */
/*  Copyright Borland International 1991, 1992                            */
/*  All Rights Reserved                                                   */
/*                                                                        */
/*------------------------------------------------------------------------*/

#if !defined( __B32VECTIMP_H )
#define __B32VECTIMP_H

#if !defined( __LIMITS_H )
#include <limits.h>
#endif  // __LIMITS_H

#if !defined( __CHECKS_H )
#include <checks.h>
#endif  // __CHECKS_H

#if !defined( __STDTEMPL_H )
#include <stdtempl.h>
#endif  // __STDTEMPL_H

// PRGM: JCL
// DESC: pragmas are no portable
// CRDT: 940715
//#ifndef UNIX
//#pragma option -Vo-
//#if defined( __BCOPT__ ) && !defined( _ALLOW_po )
//#pragma option -po-
//#endif
//#endif

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class T> class BI32_VectorImp                                 */
/*                                                                        */
/*  Implements a vector of objects of type T.  Assumes that               */
/*  T has meaningful copy semantics and a default constructor.            */
/*                                                                        */
/*------------------------------------------------------------------------*/

template <class T> class _CLASSTYPE BI32_VectorImp
{

public:

    //iend class _CLASSTYPE BI32_VectorIteratorImp<T>;

    BI32_VectorImp() :
        data(0),
        lim(0)
        {
        }

    BI32_VectorImp( unsigned long sz, unsigned long = 0 ) :
        data( new T[sz] ),
        lim(sz)
        {
        }

    BI32_VectorImp( const BI32_VectorImp<T>  & );

    const BI32_VectorImp<T>  & operator = ( const BI32_VectorImp<T>  & );

    ~BI32_VectorImp()
        {
        delete [] data;
        }

    T  & operator [] ( unsigned long index ) const
        {
        PRECONDITION( lim > 0 && data != 0 && index < lim );
        return data[index];
        }

    unsigned long limit() const
        {
        return lim;
        }

    virtual unsigned long top() const
        {
        return lim;
        }

    void resize( unsigned long, unsigned long = 0 );

    void flush( unsigned long = 0, unsigned long = ULONG_MAX, unsigned long = 0 ) {}

    void forEach( void ( *f)(T  &, void  *), void  *args )
        {
        forEach( f, args, 0, lim );
        }

    void forEach( void ( *)(T  &, void  *),
                  void  *,
                  unsigned long,
                  unsigned long
                );

    T  *firstThat( int ( *)(const T  &, void  *),
                       void  *,
                       unsigned long,
                       unsigned long
                     ) const;

    T  *firstThat( int ( *cond)(const T  &, void  *),
                       void  *args
                     ) const
        {
        return firstThat( cond, args, 0, lim );
        }

    T  *lastThat( int ( *)(const T  &, void  *),
                      void  *,
                      unsigned long,
                      unsigned long
                    ) const;

    T  *lastThat( int ( *cond)(const T  &, void  *),
                      void  *args
                    ) const
        {
        return lastThat( cond, args, 0, lim );
        }

    virtual unsigned long getDelta() const
        {
        return 0;
        }


//otected:

    T  * data;
    unsigned long lim;

    virtual void zero( unsigned long, unsigned long )
        {
        }

    virtual void removeData( T )
        {
        }

};

template <class T>
BI32_VectorImp<T>::BI32_VectorImp( const BI32_VectorImp<T>  & v ) :
    data( new T[v.lim] ),
    lim(v.lim)
{
    PRECONDITION( lim == 0 || (data != 0 && v.data != 0) );
    for( unsigned long i = 0; i < lim; i++ )
        data[i] = v.data[i];
}

template <class T>
const BI32_VectorImp<T>  & BI32_VectorImp<T>::operator = ( const BI32_VectorImp<T>  & v )
{
    if( data != v.data )
        {
        delete [] data;
        data = new T[v.lim];
        CHECK( data != 0 );
        lim = v.lim;
        for( unsigned long i = 0; i < lim; i++ )
            data[i] = v.data[i];
        }
    return *this;
}

inline unsigned long nextDelta( unsigned long sz, unsigned long delta )
{
    return (sz%delta) ? ((sz+delta)/delta)*delta : sz;
}

template <class T>
void BI32_VectorImp<T>::resize( unsigned long newSz, unsigned long offset )
{
    if( newSz <= lim || getDelta() == 0 )
        return;
    unsigned long sz = lim + nextDelta( newSz - lim, getDelta() );
    T  *temp = new T[sz];
    unsigned long last = min( sz-offset, lim );
    for( unsigned long i = 0; i < last; i++ )
        temp[i+offset] = data[i];
    delete [] data;
    data = temp;
    lim = sz;
    zero( last+offset, sz );
}

template <class T>
void BI32_VectorImp<T>::forEach( void ( *f)( T  &, void  * ),
                               void  *args,
                               unsigned long start,
                               unsigned long stop
                             )
{
    for( unsigned long cur = start; cur < stop; cur++ )
        f( data[cur], args );
}

template <class T>
T  *BI32_VectorImp<T>::firstThat( int ( *cond)( const T  &, void  * ),
                               void  *args,
                               unsigned long start,
                               unsigned long stop
                             ) const
{
    for( unsigned long cur = start; cur < stop; cur++ )
        if( cond( data[cur], args ) != 0 )
            return &data[cur];
    return 0;
}

template <class T>
T  *BI32_VectorImp<T>::lastThat( int ( *cond)( const T  &, void  * ),
                              void  *args,
                              unsigned long start,
                              unsigned long stop
                            ) const
{
    T  *res = 0;
    for( unsigned long cur = start; cur < stop; cur++ )
        if( cond( data[cur], args ) != 0 )
            res = &data[cur];
    return res;
}

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class T> class BI32_CVectorImp                                */
/*                                                                        */
/*  Implements a counted vector of objects of type T.  Assumes that       */
/*  T has meaningful copy semantics and a default constructor.            */
/*                                                                        */
/*------------------------------------------------------------------------*/

template <class T> class _CLASSTYPE BI32_CVectorImp : public BI32_VectorImp<T>
{

public:

    BI32_CVectorImp() :
        count_(0),
        delta(0)
        {
        }

    BI32_CVectorImp( unsigned long sz, unsigned long d = 0 ) :
        BI32_VectorImp<T>( sz ),
        count_(0),
        delta(d)
        {
        }

    void add( T );
    void addAt( T, unsigned long );
    void FindAndDetach( T, int = 0 );
    void detach( unsigned long, int = 0 );

    int isEmpty() const
        {
        return count_ == 0;
        }

    void forEach( void ( *f)(T  &, void  *), void  *args )
        {
        forEach( f, args, 0, count_ );
        }

    void forEach( void ( *func)(T  &, void  *),
                  void  *args,
                  unsigned long low,
                  unsigned long high
                )
        {
        BI32_VectorImp<T>::forEach( func, args, low, high );
        }

    T  *firstThat( int ( *cond)(const T  &, void  *),
                       void  *args
                     ) const
        {
        return firstThat( cond, args, 0, count_ );
        }

    T  *firstThat( int ( *cond)(const T  &, void  *),
                       void  *args,
                       unsigned long low,
                       unsigned long high
                     ) const
        {
        return BI32_VectorImp<T>::firstThat( cond, args, low, high );
        }

    T  *lastThat( int ( *cond)(const T  &, void  *),
                      void  *args
                    ) const
        {
        return lastThat( cond, args, 0, count_ );
        }

    T  *lastThat( int ( *cond)(const T  &, void  *),
                      void  *args,
                      unsigned long low,
                      unsigned long high
                    ) const
        {
        return BI32_VectorImp<T>::lastThat( cond, args, low, high );
        }

    void flush( unsigned long del = 0,
                unsigned long stop = ULONG_MAX,
                unsigned long start = 0
              )
        {
        BI32_VectorImp<T>::flush( del, stop, start ); count_ = 0;
        }

    virtual unsigned long find( T ) const;

    virtual unsigned long top() const
        {
        return count_;
        }

    unsigned long count() const
        {
        return count_;
        }

    virtual unsigned long getDelta() const
        {
        return delta;
        }

//otected:

    unsigned long count_;
    unsigned long delta;

};

template <class T> void BI32_CVectorImp<T>::add( T t )
{
    if( ++count_ > lim )
        resize( count_ );
    data[count_-1] = t;
}

template <class T> void BI32_CVectorImp<T>::addAt( T t, unsigned long loc )
{
    if( loc >= lim )
        resize( loc+1 );
    data[loc] = t;
}

template <class T> void BI32_CVectorImp<T>::FindAndDetach( T t, int del )
{
    detach( find(t), del );
}

template <class T> void BI32_CVectorImp<T>::detach( unsigned long loc, int del )
{
    if( loc >= lim )
        return;
    if( del )
        removeData( data[loc] );
    if( loc >= count_ )
        {
        zero( loc, loc+1 ); // removing an element that's not
        return;             // in the counted portion
        }
    count_--;
    for( unsigned long cur = loc; cur < count_; cur++ )
        data[cur] = data[cur+1];
    zero( count_, count_+1 );
}

template <class T> unsigned long BI32_CVectorImp<T>::find( T t ) const
{
    if( count_ != 0 )
        {
        for( unsigned long loc = 0; loc < count_; loc++ )
            if( data[loc] == t )
                return loc;
        }
    return ULONG_MAX;
}

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class T> class BI32_SVectorImp                                */
/*                                                                        */
/*  Implements a sorted vector of objects of type T.  Assumes that        */
/*  T has meaningful copy semantics, a meaningful < operator,             */
/*  and a default constructor.                                            */
/*                                                                        */
/*------------------------------------------------------------------------*/

template <class T> class _CLASSTYPE BI32_SVectorImp : public BI32_CVectorImp<T>
{

public:

    BI32_SVectorImp()
        {
        }

    BI32_SVectorImp( unsigned long sz, unsigned long d = 0 ) :
        BI32_CVectorImp<T>( sz, d )
        {
        }

    void add( T );

    virtual unsigned long find( T ) const;

};

template <class T> void BI32_SVectorImp<T>::add( T t )
{
    unsigned long loc = count_++;
    if( count_ > lim )
        resize( count_ );
    while( loc > 0 && t < data[loc-1] )
        {
        data[loc] = data[loc-1];
        loc--;
        }
    data[loc] = t;
}

template <class T> unsigned long BI32_SVectorImp<T>::find( T t ) const
{
    unsigned long lower = 0;
    unsigned long upper = count_-1;

    if( count_ != 0 )
        {
        while( lower < upper && upper != ULONG_MAX )
            {
            unsigned long middle = (lower+upper)/2;
            if( data[middle] == t )
                return middle;
            if( data[middle] < t )
                lower = middle+1;
            else
                upper = middle-1;
            }
        }
    if( lower == upper && data[lower] == t )
        return lower;
    else
        return ULONG_MAX;
}

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class T> class BI32_VectorIteratorImp                         */
/*                                                                        */
/*  Implements a vector iterator.  This iterator works with any direct    */
/*  vector.  For indirect vectors, see BI32_IVectorIteratorImp.             */
/*                                                                        */
/*------------------------------------------------------------------------*/

template <class T> class _CLASSTYPE BI32_VectorIteratorImp
{

public:

    BI32_VectorIteratorImp( const BI32_VectorImp<T>  &v )
        {
        vect = &v;
        restart(0,v.limit());
        }

    BI32_VectorIteratorImp( const BI32_VectorImp<T>  &v,
                          unsigned long start,
                          unsigned long stop
                        )
        {
        vect = &v;
        restart( start, stop );
        }


    operator int()
        {
        return cur < upper;
        }

    T current()
        {
        return (cur < upper) ? (*vect)[cur] : (*vect)[upper-1];
        }

    T operator ++ ( int )
        {
        if( cur >= upper )
            return (*vect)[upper-1];
        else
            return (*vect)[cur++];
        }

    T operator ++ ()
        {
        if( cur < upper )
            cur++;
        if( cur >= upper )
            return (*vect)[upper-1];
        else
            return (*vect)[cur];
        }

    void restart()
        {
        restart(lower,upper);
        }

    void restart( unsigned long start, unsigned long stop )
        {
        cur = lower = start;
        upper = stop;
        }

//ivate:

    const BI32_VectorImp<T>  *vect;
    unsigned long cur;
    unsigned long lower, upper;

};

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class T, class Vect> class BI32_InternalIVectorImp            */
/*                                                                        */
/*  Implements a vector of pointers to objects of type T.                 */
/*  This is implemented through the form of BI32_VectorImp specified by     */
/*  Vect.  Since pointers always have meaningful copy semantics,          */
/*  this class can handle any type of object.                             */
/*                                                                        */
/*------------------------------------------------------------------------*/
#ifndef HPUX
// The HPUX C++ Compiler does not support inheritance from a formal template
// parameter.  This class is only clled with three different Templates, all
// with a foic * parameter.  For HPUX this class will be split out.
template <class T, class Vect> class _CLASSTYPE BI32_InternalIVectorImp :
    public Vect
{

public:

    BI32_InternalIVectorImp( unsigned long sz, unsigned long d = 0 ) :
		Vect( sz, d )
	{
        zero( 0, sz );
	}

    ~BI32_InternalIVectorImp()
	{
        flush();
	}

    T  *  & operator [] ( unsigned long index )
	{
        PRECONDITION( lim == 0 || data != 0 && index < lim );
        return (T  *&)(data[index]);
	}

    T  *  operator [] ( unsigned long index ) const
	{
        PRECONDITION( lim == 0 || data != 0 && index < lim );
        return (T  *)(data[index]);
	}

    void flush( unsigned long = 0, unsigned long = ULONG_MAX, unsigned long = 0 );

    void forEach( void ( *f)(T  &, void  *), void  *args )
	{
        forEach( f, args, 0, lim );
	}

    void forEach( void ( *)(T  &, void  *),
                  void  *,
                  unsigned long,
                  unsigned long
		);

    T  *firstThat( int ( *cond)(const T  &, void  *),
                       void  *args
		) const
	{
        return firstThat( cond, args, 0, lim );
	}

    T  *firstThat( int ( *)(const T  &, void  *),
                       void  *,
                       unsigned long,
                       unsigned long
		) const;

    T  *lastThat( int ( *cond)(const T  &, void  *),
                      void  *args
		) const
	{
        return lastThat( cond, args, 0, lim );
	}

    T  *lastThat( int ( *)(const T  &, void  *),
                      void  *,
                      unsigned long,
                      unsigned long
		) const;

    virtual void zero( unsigned long, unsigned long );

//otected:

    virtual void removeData( void  *t )
	{
        delete (T  *)t;
	}

//ivate:

    static void delObj( T  &, void  * );

};

template <class T, class Vect>
void BI32_InternalIVectorImp<T,Vect>::delObj( T  &tRef, void  *vect )
{
    ((BI32_InternalIVectorImp<T,Vect> *)vect)->removeData( &tRef );
}

template <class T, class Vect>
void BI32_InternalIVectorImp<T,Vect>::flush(
                                           unsigned long del,
                                           unsigned long upr,
                                           unsigned long lwr
                                         )
{
    upr = min( upr, limit() );
    if( del )
        forEach( delObj, this, lwr, upr );
    zero( lwr, upr );
    Vect::flush( del, upr, lwr );
}

template <class T, class Vect>
void BI32_InternalIVectorImp<T,Vect>::forEach( void ( *f)( T  &, void  * ),
                                             void  *args,
                                             unsigned long start,
                                             unsigned long stop
                                           )
{
    for( unsigned long cur = start; cur < stop; cur++ )
		if( data[cur] != 0 )
			f( *(T  *)(data[cur]), args );
}

template <class T, class Vect>
T  *BI32_InternalIVectorImp<T,Vect>::firstThat( int ( *cond)( const T  &, void  * ),
                                             void  *args,
                                             unsigned long start,
                                             unsigned long stop
                                           ) const
{
    for( unsigned long cur = start; cur < stop; cur++ )
        if( data[cur] != 0 && cond( *(T  *)(data[cur]), args ) != 0 )
            return (T  *)data[cur];
    return 0;
}

template <class T, class Vect>
T  *BI32_InternalIVectorImp<T,Vect>::lastThat( int ( *cond)( const T  &, void  * ),
                                            void  *args,
                                            unsigned long start,
                                            unsigned long stop
                                          ) const
{
    T  *res = 0;
    for( unsigned long cur = start; cur < stop; cur++ )
        if( data[cur] != 0 && cond( *(T  *)(data[cur]), args ) != 0 )
            res = (T  *)data[cur];
    return res;
}

template <class T, class Vect>
void BI32_InternalIVectorImp<T,Vect>::zero( unsigned long lwr, unsigned long upr )
{
    for( unsigned long i = lwr; i < min( limit(), upr ); i++ )
		data[i] = 0;
}

#else // HPUX

////////////////////////////////////////////////////////////////////////
// Derived from BI32_VectorImp<void*>
template <class T> class _CLASSTYPE BI32_InternalIVectorImp_V :
    public BI32_VectorImp<void*>
{

public:

    BI32_InternalIVectorImp_V( unsigned long sz, unsigned long d = 0 ) :
		BI32_VectorImp<void*>( sz, d )
	{
        zero( 0, sz );
	}

    ~BI32_InternalIVectorImp_V()
	{
        flush();
	}

    T  *  & operator [] ( unsigned long index )
	{
        PRECONDITION( lim == 0 || data != 0 && index < lim );
        return (T  *&)(data[index]);
	}

    T  *  & operator [] ( unsigned long index ) const
	{
        PRECONDITION( lim == 0 || data != 0 && index < lim );
        return (T  *&)(data[index]);
	}

    void flush( unsigned long = 0, unsigned long = ULONG_MAX, unsigned long = 0 );

    void forEach( void ( *f)(T  &, void  *), void  *args )
	{
        forEach( f, args, 0, lim );
	}

    void forEach( void ( *)(T  &, void  *),
                  void  *,
                  unsigned long,
                  unsigned long
		);

    T  *firstThat( int ( *cond)(const T  &, void  *),
                       void  *args
		) const
	{
        return firstThat( cond, args, 0, lim );
	}

    T  *firstThat( int ( *)(const T  &, void  *),
                       void  *,
                       unsigned long,
                       unsigned long
		) const;

    T  *lastThat( int ( *cond)(const T  &, void  *),
                      void  *args
		) const
	{
        return lastThat( cond, args, 0, lim );
	}

    T  *lastThat( int ( *)(const T  &, void  *),
                      void  *,
                      unsigned long,
                      unsigned long
		) const;

    virtual void zero( unsigned long, unsigned long );

//otected:

    virtual void removeData( void  *t )
	{
        delete (T  *)t;
	}

//ivate:

    static void delObj( T  &, void  * );

};

template <class T>
void BI32_InternalIVectorImp_V<T>::delObj( T  &tRef, void  *vect )
{
    ((BI32_InternalIVectorImp_V<T> *)vect)->removeData( &tRef );
}

template <class T>
void BI32_InternalIVectorImp_V<T>::flush(
                                           unsigned long del,
                                           unsigned long upr,
                                           unsigned long lwr
                                         )
{
    upr = min( upr, limit() );
    if( del )
        forEach( delObj, this, lwr, upr );
    zero( lwr, upr );
    BI32_VectorImp<void*>::flush( del, upr, lwr );
}

template <class T>
void BI32_InternalIVectorImp_V<T>::forEach( void ( *f)( T  &, void  * ),
                                             void  *args,
                                             unsigned long start,
                                             unsigned long stop
                                           )
{
    for( unsigned long cur = start; cur < stop; cur++ )
		if( data[cur] != 0 )
			f( *(T  *)(data[cur]), args );
}

template <class T>
T  *BI32_InternalIVectorImp_V<T>::firstThat( int ( *cond)( const T  &, void  * ),
                                             void  *args,
                                             unsigned long start,
                                             unsigned long stop
                                           ) const
{
    for( unsigned long cur = start; cur < stop; cur++ )
        if( data[cur] != 0 && cond( *(T  *)(data[cur]), args ) != 0 )
            return (T  *)data[cur];
    return 0;
}

template <class T>
T  *BI32_InternalIVectorImp_V<T>::lastThat( int ( *cond)( const T  &, void  * ),
                                            void  *args,
                                            unsigned long start,
                                            unsigned long stop
                                          ) const
{
    T  *res = 0;
    for( unsigned long cur = start; cur < stop; cur++ )
        if( data[cur] != 0 && cond( *(T  *)(data[cur]), args ) != 0 )
            res = (T  *)data[cur];
    return res;
}

template <class T>
void BI32_InternalIVectorImp_V<T>::zero( unsigned long lwr, unsigned long upr )
{
    for( unsigned long i = lwr; i < min( limit(), upr ); i++ )
		data[i] = 0;
}

////////////////////////////////////////////////////////////////////////
// Derived from BI32_CVectorImp<void*>

template <class T> class _CLASSTYPE BI32_InternalIVectorImp_CV :
    public BI32_CVectorImp<void*>
{

public:

    BI32_InternalIVectorImp_CV( unsigned long sz, unsigned long d = 0 ) :
		BI32_CVectorImp<void*>( sz, d )
	{
        zero( 0, sz );
	}

    ~BI32_InternalIVectorImp_CV()
	{
        flush();
	}

    T  *  & operator [] ( unsigned long index )
	{
        PRECONDITION( lim == 0 || data != 0 && index < lim );
        return (T  *&)(data[index]);
	}

    T  *  & operator [] ( unsigned long index ) const
	{
        PRECONDITION( lim == 0 || data != 0 && index < lim );
        return (T  *&)(data[index]);
	}

    void flush( unsigned long = 0, unsigned long = ULONG_MAX, unsigned long = 0 );

    void forEach( void ( *f)(T  &, void  *), void  *args )
	{
        forEach( f, args, 0, lim );
	}

    void forEach( void ( *)(T  &, void  *),
                  void  *,
                  unsigned long,
                  unsigned long
		);

    T  *firstThat( int ( *cond)(const T  &, void  *),
                       void  *args
		) const
	{
        return firstThat( cond, args, 0, lim );
	}

    T  *firstThat( int ( *)(const T  &, void  *),
                       void  *,
                       unsigned long,
                       unsigned long
		) const;

    T  *lastThat( int ( *cond)(const T  &, void  *),
                      void  *args
		) const
	{
        return lastThat( cond, args, 0, lim );
	}

    T  *lastThat( int ( *)(const T  &, void  *),
                      void  *,
                      unsigned long,
                      unsigned long
		) const;

    virtual void zero( unsigned long, unsigned long );

//otected:

    virtual void removeData( void  *t )
	{
        delete (T  *)t;
	}

//ivate:

    static void delObj( T  &, void  * );

};

template <class T>
void BI32_InternalIVectorImp_CV<T>::delObj( T  &tRef, void  *vect )
{
    ((BI32_InternalIVectorImp_CV<T> *)vect)->removeData( &tRef );
}

template <class T>
void BI32_InternalIVectorImp_CV<T>::flush(
                                           unsigned long del,
                                           unsigned long upr,
                                           unsigned long lwr
                                         )
{
    upr = min( upr, limit() );
    if( del )
        forEach( delObj, this, lwr, upr );
    zero( lwr, upr );
    BI32_CVectorImp<void*>::flush( del, upr, lwr );
}

template <class T>
void BI32_InternalIVectorImp_CV<T>::forEach( void ( *f)( T  &, void  * ),
                                             void  *args,
                                             unsigned long start,
                                             unsigned long stop
                                           )
{
    for( unsigned long cur = start; cur < stop; cur++ )
		if( data[cur] != 0 )
			f( *(T  *)(data[cur]), args );
}

template <class T>
T  *BI32_InternalIVectorImp_CV<T>::firstThat( int ( *cond)( const T  &, void  * ),
                                             void  *args,
                                             unsigned long start,
                                             unsigned long stop
                                           ) const
{
    for( unsigned long cur = start; cur < stop; cur++ )
        if( data[cur] != 0 && cond( *(T  *)(data[cur]), args ) != 0 )
            return (T  *)data[cur];
    return 0;
}

template <class T>
T  *BI32_InternalIVectorImp_CV<T>::lastThat( int ( *cond)( const T  &, void  * ),
                                            void  *args,
                                            unsigned long start,
                                            unsigned long stop
                                          ) const
{
    T  *res = 0;
    for( unsigned long cur = start; cur < stop; cur++ )
        if( data[cur] != 0 && cond( *(T  *)(data[cur]), args ) != 0 )
            res = (T  *)data[cur];
    return res;
}

template <class T>
void BI32_InternalIVectorImp_CV<T>::zero( unsigned long lwr, unsigned long upr )
{
    for( unsigned long i = lwr; i < min( limit(), upr ); i++ )
		data[i] = 0;
}


////////////////////////////////////////////////////////////////////////
// Derived from BI32_SVectorImp<void*>

template <class T> class _CLASSTYPE BI32_InternalIVectorImp_SV :
    public BI32_SVectorImp<void*>
{

public:

    BI32_InternalIVectorImp_SV( unsigned long sz, unsigned long d = 0 ) :
		BI32_SVectorImp<void*>( sz, d )
	{
        zero( 0, sz );
	}

    ~BI32_InternalIVectorImp_SV()
	{
        flush();
	}

    T  *  & operator [] ( unsigned long index )
	{
        PRECONDITION( lim == 0 || data != 0 && index < lim );
        return (T  *&)(data[index]);
	}

    T  *  & operator [] ( unsigned long index ) const
	{
        PRECONDITION( lim == 0 || data != 0 && index < lim );
        return (T  *&)(data[index]);
	}

    void flush( unsigned long = 0, unsigned long = ULONG_MAX, unsigned long = 0 );

    void forEach( void ( *f)(T  &, void  *), void  *args )
	{
        forEach( f, args, 0, lim );
	}

    void forEach( void ( *)(T  &, void  *),
                  void  *,
                  unsigned long,
                  unsigned long
		);

    T  *firstThat( int ( *cond)(const T  &, void  *),
                       void  *args
		) const
	{
        return firstThat( cond, args, 0, lim );
	}

    T  *firstThat( int ( *)(const T  &, void  *),
                       void  *,
                       unsigned long,
                       unsigned long
		) const;

    T  *lastThat( int ( *cond)(const T  &, void  *),
                      void  *args
		) const
	{
        return lastThat( cond, args, 0, lim );
	}

    T  *lastThat( int ( *)(const T  &, void  *),
                      void  *,
                      unsigned long,
                      unsigned long
		) const;

    virtual void zero( unsigned long, unsigned long );

//otected:

    virtual void removeData( void  *t )
	{
        delete (T  *)t;
	}

//ivate:

    static void delObj( T  &, void  * );

};

template <class T>
void BI32_InternalIVectorImp_SV<T>::delObj( T  &tRef, void  *vect )
{
    ((BI32_InternalIVectorImp_SV<T> *)vect)->removeData( &tRef );
}

template <class T>
void BI32_InternalIVectorImp_SV<T>::flush(
                                           unsigned long del,
                                           unsigned long upr,
                                           unsigned long lwr
                                         )
{
    upr = min( upr, limit() );
    if( del )
        forEach( delObj, this, lwr, upr );
    zero( lwr, upr );
    BI32_SVectorImp<void*>::flush( del, upr, lwr );
}

template <class T>
void BI32_InternalIVectorImp_SV<T>::forEach( void ( *f)( T  &, void  * ),
                                             void  *args,
                                             unsigned long start,
                                             unsigned long stop
                                           )
{
    for( unsigned long cur = start; cur < stop; cur++ )
		if( data[cur] != 0 )
			f( *(T  *)(data[cur]), args );
}

template <class T>
T  *BI32_InternalIVectorImp_SV<T>::firstThat( int ( *cond)( const T  &, void  * ),
                                             void  *args,
                                             unsigned long start,
                                             unsigned long stop
                                           ) const
{
    for( unsigned long cur = start; cur < stop; cur++ )
        if( data[cur] != 0 && cond( *(T  *)(data[cur]), args ) != 0 )
            return (T  *)data[cur];
    return 0;
}

template <class T>
T  *BI32_InternalIVectorImp_SV<T>::lastThat( int ( *cond)( const T  &, void  * ),
                                            void  *args,
                                            unsigned long start,
                                            unsigned long stop
                                          ) const
{
    T  *res = 0;
    for( unsigned long cur = start; cur < stop; cur++ )
        if( data[cur] != 0 && cond( *(T  *)(data[cur]), args ) != 0 )
            res = (T  *)data[cur];
    return res;
}

template <class T>
void BI32_InternalIVectorImp_SV<T>::zero( unsigned long lwr, unsigned long upr )
{
    for( unsigned long i = lwr; i < min( limit(), upr ); i++ )
		data[i] = 0;
}

#endif
/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class T> class BI32_IVectorImp                                */
/*                                                                        */
/*  Implements a vector of pointers to objects of type T.                 */
/*  This is implemented through the template BI32_InternalIVectorImp.       */
/*  Since pointers always have meaningful copy semantics, this class      */
/*  can handle any type of object.                                        */
/*                                                                        */
/*------------------------------------------------------------------------*/

template <class T> class _CLASSTYPE BI32_IVectorImp :
#ifndef HPUX
    public BI32_InternalIVectorImp<T, BI32_VectorImp<void  *> >
#else
	public BI32_InternalIVectorImp_V<T>
#endif
{

public:

    BI32_IVectorImp( unsigned long sz ) :
#ifndef HPUX
        BI32_InternalIVectorImp<T, BI32_VectorImp<void  *> >(sz)
#else
        BI32_InternalIVectorImp_V<T>(sz)
#endif
        {
        }


};

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class T> class BI32_ICVectorImp                               */
/*                                                                        */
/*  Implements a counted vector of pointers to objects of type T.         */
/*  Since pointers always have meaningful copy semantics, this class      */
/*  can handle any type of object.                                        */
/*                                                                        */
/*------------------------------------------------------------------------*/

template <class T> class _CLASSTYPE BI32_ICVectorImp :
#ifndef HPUX
    public BI32_InternalIVectorImp<T, BI32_CVectorImp<void  *> >
#else
    public BI32_InternalIVectorImp_CV<T>
#endif
{

public:

    BI32_ICVectorImp( unsigned long sz, unsigned long d = 0 ) :
#ifndef HPUX
        BI32_InternalIVectorImp<T, BI32_CVectorImp<void  *> >(sz)
#else
        BI32_InternalIVectorImp_CV<T>(sz)
#endif
        {
			delta = d;
        }

    unsigned long find( T  *t ) const
        {
			return find( (void  *)t );
        }

    void add( T  *t );

//otected:

    virtual unsigned long find( void  * ) const;

};

template <class T> unsigned long BI32_ICVectorImp<T>::find( void  *t ) const
{
    if( limit() != 0 )
	{
        for( unsigned long loc = 0; loc < limit(); loc++ )
            if( data[loc] &&
                *(const T  *)(data[loc]) == *(const T  *)t
				)
                return loc;
	}
    return ULONG_MAX;
}

template <class T > void BI32_ICVectorImp<T>::add( T  *t )
{
    while( count_ < limit() && (*this)[count_] != 0 )
        count_++;
#ifndef HPUX
    BI32_InternalIVectorImp<T, BI32_CVectorImp<void  *> >::add(t);
#else
    BI32_InternalIVectorImp_CV<T>::add(t);
#endif
}

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class T> class BI32_ISVectorImp                               */
/*                                                                        */
/*  Implements a sorted vector of pointers to objects of type T.          */
/*  This is implemented through the template BI32_InternalIVectorImp.       */
/*  Since pointers always have meaningful copy semantics, this class      */
/*  can handle any type of object.                                        */
/*                                                                        */
/*------------------------------------------------------------------------*/

template <class T> class _CLASSTYPE BI32_ISVectorImp :
#ifndef HPUX
    public BI32_InternalIVectorImp<T, BI32_SVectorImp<void  *> >
#else
    public BI32_InternalIVectorImp_SV<T>
#endif
{

public:

    BI32_ISVectorImp( unsigned long sz, unsigned long d = 0 ) :
#ifndef HPUX
        BI32_InternalIVectorImp<T, BI32_SVectorImp<void  *> >(sz)
#else
        BI32_InternalIVectorImp_SV<T>(sz)
#endif
        {
        delta = d;
        }

    unsigned long find( T  *t ) const
        {
        return find( (void  *)t );
        }

    void add( T  *t );

//otected:

    virtual unsigned long find( void  * ) const;

};

template <class T> unsigned long BI32_ISVectorImp<T>::find( void  *t ) const
{
    unsigned long lower = 0;
    unsigned long upper = count_-1;
    if( count_ != 0 )
	{
        while( lower < upper && upper != ULONG_MAX )
		{
            unsigned long middle = (lower+upper)/2;
            // if( *(const T  *)(data[middle]) == *(const T  *)t )
            if( *(T  *)(data[middle]) == *(T  *)t )
                return middle;
            // if( *(const T  *)(data[middle]) < *(const T  *)t )
            if( *(T  *)(data[middle]) < *(T  *)t )
                lower = middle+1;
            else
                upper = middle-1;
		}
	}
    // if( lower == upper && *(const T *)(data[lower]) == *(const T *)t )
    if( lower == upper && *(T *)(data[lower]) == *(T *)t )
        return lower;
    else
        return ULONG_MAX;
}

template <class T> void BI32_ISVectorImp<T>::add( T  *t )
{
    unsigned long loc = count_++;
    if( count_ > lim )
        resize( count_ );
    while( loc > 0 && *t < *((T  *)(*this)[loc-1]) )
	{
        data[loc] = data[loc-1];
        loc--;
	}
    data[loc] = t;
}

/*------------------------------------------------------------------------*/
/*                                                                        */
/*  template <class T> class BI32_IVectorIteratorImp                        */
/*                                                                        */
/*  Implements a vector iterator.  This iterator works with any indirect  */
/*  vector.  For direct vectors, see BI32_VectorIteratorImp.                */
/*                                                                        */
/*------------------------------------------------------------------------*/

template <class T> class _CLASSTYPE BI32_IVectorIteratorImp :
    public BI32_VectorIteratorImp<void  *>
{

public:

    BI32_IVectorIteratorImp( const BI32_VectorImp<void  *>  &v ) :
        BI32_VectorIteratorImp<void  *>(v)
        {
        bump();
        }

    BI32_IVectorIteratorImp( const BI32_VectorImp<void  *>  &v,
                           unsigned long l, unsigned long u
                         ) :
        BI32_VectorIteratorImp<void  *>(v,l,u)
        {
        bump();
        }

    T  *current()
        {
        return (T  *)BI32_VectorIteratorImp<void  *>::current();
        }

    T  *operator ++ ( int );
    T  *operator ++ ();

    void restart()
        {
        BI32_VectorIteratorImp<void  *>::restart();
        bump();
        }

    void restart( unsigned long start, unsigned long stop )
        {
        BI32_VectorIteratorImp<void  *>::restart( start, stop );
        bump();
        }

//ivate:

    void bump();

};

template <class T> T  * BI32_IVectorIteratorImp<T>::operator ++ ()
{
    BI32_VectorIteratorImp<void  *>::operator++();
    bump();
    return (T  *)current();
}

template <class T> T  * BI32_IVectorIteratorImp<T>::operator ++ ( int )
{
    void *temp = current();
    BI32_VectorIteratorImp<void  *>::operator++(1);
    bump();
    return (T  *)temp;
}

template <class T> void BI32_IVectorIteratorImp<T>::bump()
{
    while( *this != 0 && current() == 0 )
        BI32_VectorIteratorImp<void  *>::operator++();
}

// PRGM: JCL
// DESC: pragmas are no portable
// CRDT: 940715
//#ifndef UNIX
//#if defined( __BCOPT__ ) && !defined( _ALLOW_po )
//#pragma option -po.
//#endif
//#pragma option -Vo.
//#endif

#endif // __B32VECTIMP_H
