#include <limits.h>

main()
{
	int i = INT_MAX;

	int a;

	a = i;

}