// Copyright (C) 1995 Treasury Services Corporation ALL RIGHTS RESERVED

#ifndef INC_IO_LSTERA_H
#define INC_IO_LSTERA_H 1

#include <lenmax.h>
#include <simpstr.h>

#include "io_lsimp.h"

class _export io_ledger_stat;
class _export TemporaryTable;

//@DESC: Class for implementing teradata version of io_lstat_complete
//@PGMR: LDC
//@CRDT: 19950821
class _export io_lstat_tera : public LstatCompleteImpl
{
public:

	io_lstat_tera(SimpleString TableName, double ProcId,
					  short pStartMonth, short pStopMonth);

	~io_lstat_tera();

	//@DESC: Return construction status.
	//@PGMR: LDC
	//@CRDT: 19950821
	virtual operator BOOL() const
	{
		return TRUE;
	}

	int SetStart(DBHandle);
	int SetNext(LEDGER_STAT* BufPtr);
	int SetEnd();

private:
	BOOL CopyTmpTableToLStat();
	BOOL UpdateExisting(const char* KeyList);
	BOOL InsertNew(const char* KeyList);
	
	void InsertSelect(ostream& strm,
							const char* ViewName,
							const char* ColName) const;
	void InsertSelectWhere(ostream&,
								  const char* ViewName) const;

	SimpleString mTableName;	  // @DESC: Name of ledger table
	short mStartMonth;			  // @DESC: Start month
	short mStopMonth;				  // @DESC: Stop month
	DBHandle mHandle;				  // @DESC: Handle to database
	
	double mProcTag;				  // @DESC: number to use to guarantee unique table
	io_ledger_stat* mInsert;			//@DESC: insert io for temporary table
	TemporaryTable* mTmpTable;			//@DESC: Temporary Table
};

#endif // INC_IO_LSTERA_H
