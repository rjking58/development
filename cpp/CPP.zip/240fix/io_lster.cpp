// Copyright (C) 1995 Treasury Services Corporation ALL RIGHTS RESERVED

//COMPILER
#include <assert.h>
#include <iostream.h>
#include <iomanip.h>
#include <limits.h>

//UTILS
#include <utils.h>
#include <lookup.h>
#include <tscdebug.h>

//ACC
#include <acc_sesn.h>
#include <drv_main.h>
#include <tbldefs.h>

//IOMOD
#include <read_ini.h>

//DBMEM
#include "clmem.h"
#include "leafinfo.h"
#include "idenmem.h"
#include "io_lstat.h"
#include "io_lster.h"
#include "iosql.h"
#include "tmptable.h"
	 
//-------------------------------------------------------------------------
//DESC:  Class constructor.
//			1) Setup memory areas for data in results sets created by SQL calls.
//			2) Setup database views - a map of how to put data into memory areas
//				allocated in above step.
//PGMR:	LDC
//CRDT:	931104
//-------------------------------------------------------------------------
io_lstat_tera::io_lstat_tera(SimpleString TableName,
									  double ProcTag,
									  short StartMonth, 
									  short StopMonth)
	: mTmpTable(0),
	  mInsert(0),
	  mStartMonth(StartMonth),
	  mStopMonth(StopMonth),
	  mTableName(TableName),
	  mHandle(-1),
	  mProcTag(ProcTag)
{
}

//@DESC: Destructor
//@PGMR: LDC
//@CRDT: 19960611
io_lstat_tera::~io_lstat_tera()
{
	// Both of these should have already been deleted.
	delete mTmpTable;
	delete mInsert;
}


//@DESC: Prepare to run.
//@PGMR: LDC
//@CRDT: 19960610
int io_lstat_tera::SetStart(DBHandle HandleNum)
{
	mTmpTable = new TemporaryTable("ALLOC", mTableName,
											 mProcTag, HandleNum);

	mHandle = HandleNum;

	if (mTmpTable && *mTmpTable && mTmpTable->Create())
	{
		mInsert = new io_ledger_stat(mStartMonth, mStopMonth, HandleNum, FALSE,
											  mTmpTable->GetTableName());


		if (mInsert != 0)
		{
			int Sessions = 1;
			int Requests = 1;
			int Statements = 11;

			// what do i do with IniTableName? tserpr.ini has to change.
			read_ini::GetMultiModeOptions("Teradata_Ledger_Stat",
													&Sessions,
													&Requests,
													&Statements);

			if (mInsert->SetupMultiMode(Sessions, Requests, Statements) == 0)
			{
				// Do we do anything here, a warning will already be printed,
				// but should we still let it run?
				delete mInsert;
				mInsert = 0;
			}
			else
			{
				if (!mInsert->PrepareInsert())
				{
					delete mInsert;
					mInsert = 0;
				}
			}
		}
	}

	return mInsert != 0;
}

//-------------------------------------------------------------------------
//DESC:	Class destructor.
//			1) Call ClearWheres member function for each database view created
//				in constructor.
//			2) Free memory buffers allocated in constructor.
//PGMR:	LDC
//CRDT:	930824
//-------------------------------------------------------------------------
int io_lstat_tera::SetEnd()
{
	assert(mHandle >= 0);
	
	BOOL Status = TRUE;
	
	if (mInsert)
	{
		Status = mInsert->SaveEnd();
		TSCLog(CALC_LOG,
				 LOW,
				 "io_lstat_tera Insert Statements: %d\n",
				 mInsert->GoodStmtCount());
		if (Status)
		{
			Status = CopyTmpTableToLStat();
		}
	}

	delete mInsert;
	delete mTmpTable;

	mInsert = 0;
	mTmpTable = 0;

	return Status;
}

//-------------------------------------------------------------------------
//DESC:	Update or Add the import record to the data base by calling the appropriate
//		   SQL parsers and executing the Update or Insert command.
//PGMR:	LDC, 930810
//-------------------------------------------------------------------------
int io_lstat_tera::SetNext(LEDGER_STAT* BufPtr)
{
	long RowsAffected; // Unused
	
	return mInsert->SetNext(BufPtr);
}

//@DESC: Copy information in tmp table to ledger_stat
//@PGMR: LDC
//@CRDT: 19950822
BOOL io_lstat_tera::CopyTmpTableToLStat()
{
	BOOL RtnVal = TRUE;

	// We need a list of the key columns
	ostrstream keystrm;

	keystrm << "identity_code,year_s,accum_type_cd,consolidation_cd";

	for (LeafIterator LeafInfo(FALSE); LeafInfo; LeafInfo++)
	{
		keystrm << "," << LeafInfo.Current()->leaf_field;
	}
	keystrm << ends;

	char* KeyFields = keystrm.str();

	RtnVal = UpdateExisting(KeyFields);
	if (RtnVal)
	{
		RtnVal = InsertNew(KeyFields);
	}

	return RtnVal;
}

//@DESC: Update existing rows in ledger_stat from tmptable
//@PGMR: LDC
//@CRDT: 19960611
BOOL io_lstat_tera::UpdateExisting(const char* KeyList)
{
	ostrstream UpdateStream;

	UpdateStream << "update " << mTableName  << " set  ";
	for (int i = mStartMonth; i <= mStopMonth; i++)
	{
		if (i > mStartMonth)
		{
			UpdateStream << ",";
		}

		char MonthCol[20];
		char YearCol[20];

		ostrstream MStrm(MonthCol, sizeof(MonthCol));
		ostrstream YStrm(YearCol, sizeof(YearCol));

		MStrm << "month_" << setw(2) << setfill('0') << i << ends;
		YStrm << "ytd_" << setw(2) << setfill('0') << i << ends;
		
		InsertSelect(UpdateStream, mTmpTable->GetTableName(), MonthCol);
		UpdateStream << ",";
		InsertSelect(UpdateStream, mTmpTable->GetTableName(), YearCol);
	}

	for (int j = mStopMonth + 1; j <= GetPeriodEnd(mStartMonth); j++)
	{
		char YearCol[20];

		ostrstream YStrm(YearCol, sizeof(YearCol));

		YStrm << "ytd_" << setw(2) << setfill('0') << j << ends;

		UpdateStream << ",";
		
		InsertSelect(UpdateStream, mTmpTable->GetTableName(), YearCol);
	}

	InsertSelectWhere(UpdateStream, mTmpTable->GetTableName());

	BOOL ReturnStatus = ExecuteDirect(UpdateStream.str(), 0, mHandle);
	UpdateStream.rdbuf()->freeze(0);
	
	return ReturnStatus;
}

//@DESC: Inserts new rows into ledger_stat
//@PGMR: LDC
//@CRDT: 19960611
BOOL io_lstat_tera::InsertNew(const char* KeyList)
{
	ostrstream InsertStream;

	InsertStream << "insert into " << mTableName;
	InsertStream << " select * from ";
	InsertStream << mTmpTable->GetTableName() << " where (" << KeyList
			  << ") not in (select " << KeyList << " from "
			  << mTableName << ")" << ends;

	char* InsertSQL = InsertStream.str();

	int RtnVal = ExecuteDirect(InsertStream.str(), 0, mHandle);
	InsertStream.rdbuf()->freeze(0);

	return RtnVal;
}

//@DESC: Insert a select column into strm
//@PGMR: LDC
//@CRDT: 19950824
void io_lstat_tera::InsertSelect(ostream& strm,
											const char* ViewName,
											const char* ColName) const
{
	assert(mHandle >= 0);

	switch (GetSession()->GetDBType(mHandle))
	{
		case DRV_TERADATA:
			// Teradata makes this much easier.
			strm << ColName << '=';
			strm << ViewName << '.' << ColName;
			strm << '+' << mTableName << '.' << ColName;
			break;

		default:
		{
			// This works for Oracle, don't know about the others
			strm << "(select " << ColName
				  << '+' << mTableName << '.' << ColName;
	
			strm << " from " << ViewName;

			InsertSelectWhere(strm, ViewName);

			strm << ')';
			break;
		}
	}
}

//@DESC: Insert a select column into strm
//@PGMR: LDC
//@CRDT: 19950901
void io_lstat_tera::InsertSelectWhere(ostream& strm,
												  const char* ViewName) const
{
	strm << " where " << mTableName << ".identity_code="
		  << ViewName << ".identity_code and "
		  << mTableName << ".year_s="
		  << ViewName << ".year_s and "
		  << mTableName << ".accum_type_cd="
		  << ViewName << ".accum_type_cd and "
		  << mTableName << ".consolidation_cd="
		  << ViewName << ".consolidation_cd";

	for (LeafIterator LeafInfo(TRUE); LeafInfo; LeafInfo++)
	{
		strm << " and "
			  << mTableName << '.' << LeafInfo.Current()->leaf_field
			  << '=' << ViewName << '.'
			  << LeafInfo.Current()->leaf_field;
	}
}
