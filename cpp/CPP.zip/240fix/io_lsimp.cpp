// Copyright (C) 1995 Treasury Services Corporation ALL RIGHTS RESERVED

#include <inidata.h>

#include "io_lsimp.h"
#include "io_lster.h"
#include "io_lsora.h"

#include <assert.h>

//@DESC: Constructor
//@PGMR: LDC
//@CRDT: 19950921
LstatCompleteImpl *LstatCompleteImpl::GetPreferedLSImp(
	SimpleString TableName,
	DBHandle HandleNum,
	double ProcTag,
	short StartMonth,
	short NumMonths)
{
	assert(NumMonths > 0);
	
	LstatCompleteImpl* IoCompleteImpl = 0;
	int StopMonth = StartMonth + NumMonths - 1;
	
	int ForceUpsertMethod =
		IniData::GetIniData()->GetPrivateInt("TeraData", "UpsertMethod", 0);

	if (ForceUpsertMethod != 0)
	{
		switch (ForceUpsertMethod)
		{
			case 1:
				IoCompleteImpl = new io_lstat_tera(TableName,
															  ProcTag,									
															  StartMonth,
															  StopMonth);
				break;

			case 2:
				IoCompleteImpl = new io_lstat_ora(TableName,
															 StartMonth,
															 StopMonth);
				break;
		}
	}
	else
	{
		switch (GetSession()->GetDBType(HandleNum))
		{
			case DRV_TERADATA:
				IoCompleteImpl = new io_lstat_tera(TableName,
															  ProcTag,
															  StartMonth,
															  StopMonth);

				// This is a really ugly way to implement this.
				if (IoCompleteImpl == 0 || !*IoCompleteImpl) 
				{
					MessageBox(GetActiveWindow(), "Teradata lstat failed, using"
								  " default version", "Teradata Warning",
								  MB_OK);
					// else fall through and use the default version.
				}
				else
				{
					break;
				}
			
			default:
				IoCompleteImpl = new io_lstat_ora(TableName,
															 StartMonth,
															 StopMonth);
				break;
		}
	}

	return IoCompleteImpl;
}

//@DESC: Empty constructor
//@PGMR: LDC
//@CRDT: 19950921
LstatCompleteImpl::LstatCompleteImpl()
{
}


//@DESC: Destructor
//@PGMR: LDC
//@CRDT: 19950921
LstatCompleteImpl::~LstatCompleteImpl()
{
}
