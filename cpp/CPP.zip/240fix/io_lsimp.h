// Copyright (C) 1995 Treasury Services Corporation ALL RIGHTS RESERVED

#ifndef INC_IO_LSIMP_H
#define INC_IO_LSIMP_H 1

#include <acc_sesn.h>
#include <simpstr.h>

struct LEDGER_STAT;

class _export LstatCompleteImpl;

//@DESC: Class that abstracts out different methods of inserting into the
//			ledger_stat table depending on database type.
//@PGMR: LDC
//@CRDT: 19950921
class _export LstatCompleteImpl
{
public:
	LstatCompleteImpl();
	virtual ~LstatCompleteImpl();

	static LstatCompleteImpl* GetPreferedLSImp(
		SimpleString TableName,
		DBHandle, double ProcTag,
		short StartMonth, short NumMonths
	);

	//@DESC: Status of construction
	//@PGMR: LDC
	//@CRDT: 19950921
	virtual operator BOOL() const
	{
		return TRUE;
	}

	virtual int SetStart(DBHandle) = 0;
	virtual int SetNext(LEDGER_STAT*) = 0;
	virtual int SetEnd() = 0;
};

#endif // INC_IO_LSIMP_H
