// Copyright (C) 1995 Treasury Services Corporation ALL RIGHTS RESERVED

#ifndef INC_IO_LSORA_H
#define INC_IO_LSORA_H 1

#include <io_lsimp.h>
#include <simpstr.h>

class _export io_ledger_stat;

//@DESC:	This class contains performs a LEDGER_STAT Update or Insert depending
//       upon whether the Update was successful.  It constructs 2 IO_LEDGER_STAT
//       objects and updates the identity code table.
//@PGMR:	DPM
//@CRDT:	931104
//@MNT: LDC 19950821 Ar# <Unable to find in TSER/AR, fix the product!>

class _export io_lstat_ora : public LstatCompleteImpl
{
public:

	io_lstat_ora(SimpleString FileName, short StartMonth, short StopMonth);

	~io_lstat_ora();

	virtual int SetStart(DBHandle);
	virtual int SetNext(LEDGER_STAT*);
	virtual int SetEnd();

	virtual operator BOOL() const 
	{
		return TRUE;
	}

private:
	SimpleString mTableName;
	short mStartMonth;			  // @DESC: Start month to write out
	short mStopMonth;				  // @DESC: End month to write out

	DBHandle mHandle;				  // @DESC: Last used handle

	io_ledger_stat      *io_lstat_ins;                 // @DESC: Pointer to IO class for Insert statement
	io_ledger_stat      *io_lstat_upd;  					// @DESC: Pointer to IO class for Update statement
};


#endif // INC_IO_LSORA_H
