// Copyright (C) 1995 Treasury Services Corporation ALL RIGHTS RESERVED

//COMPILER
#include <iostream.h>
#include <tscdebug.h>
#include <limits.h>

#include <utils.h>

//DBMEM
#include "io_lsora.h"
#include "io_lstat.h"
	 
//-------------------------------------------------------------------------
//DESC:  Class constructor.
//			1) Setup memory areas for data in results sets created by SQL calls.
//			2) Setup database views - a map of how to put data into memory areas
//				allocated in above step.
//PGMR:	DPM
//CRDT:	931104
//-------------------------------------------------------------------------
io_lstat_ora::io_lstat_ora(SimpleString TableName,
									short StartMonth,
									short StopMonth)
	: io_lstat_ins(0),
	  io_lstat_upd(0),
	  mStartMonth(StartMonth),
	  mStopMonth(StopMonth),
	  mHandle(-1),
	  mTableName(TableName)
{
}

//@DESC: Prepare for writing
//@PGMR: LDC
//@CRDT: 19960610
int io_lstat_ora::SetStart(DBHandle HandleNum)
{
	// Delete old ones
	delete io_lstat_ins;
	delete io_lstat_upd;
		
	// Construct Insert Object
	io_lstat_ins = new io_ledger_stat( mStartMonth, GetPeriodEnd(mStartMonth),
												  HandleNum, FALSE, mTableName );
	io_lstat_upd = new io_ledger_stat( mStartMonth, GetPeriodEnd(mStartMonth),
												  HandleNum, TRUE, mTableName );
	mHandle = HandleNum;

	if ( io_lstat_upd && io_lstat_ins )
	{
		// Now Prepare Insert
		if (io_lstat_ins->PrepareInsert( NULL ))
		{
			// Now Prepare Updates
			if (!io_lstat_upd->PrepareUpdate(FALSE))
			{
				delete io_lstat_upd;
				io_lstat_upd = 0;
			}
		}
		else
		{
			delete io_lstat_ins;
			io_lstat_ins = 0;
		}
	}

	return io_lstat_ins && io_lstat_upd;
}

//-------------------------------------------------------------------------
//DESC:	Class destructor.
//			1) Call ClearWheres member function for each database view created
//				in constructor.
//			2) Free memory buffers allocated in constructor.
//PGMR:	DPM
//CRDT:	930824
//-------------------------------------------------------------------------
io_lstat_ora::~io_lstat_ora()
{
	delete io_lstat_ins;
	delete io_lstat_upd;
}

//-------------------------------------------------------------------------
//DESC:	Update or Add the import record to the data base by calling the appropriate
//		   SQL parsers and executing the Update or Insert command.
//PGMR:	DPM, 930810
//-------------------------------------------------------------------------
int io_lstat_ora::SetNext(LEDGER_STAT* BufPtr)
{
	 int           rtncode = TRUE;
	 long          RowsAffected;

	 // Try and Update current record first
	 if (!io_lstat_upd->DoUpdate(BufPtr, RowsAffected))
	 {
		 rtncode = FALSE;
	 }
	 else if ( RowsAffected == 0 )
	 {
		  if ( !io_lstat_ins->SetNext( BufPtr ) )
		  {
				rtncode = FALSE;
		  }
	 }

	 return( rtncode );
}

//@DESC: Finish writing
//@PGMR: LDC
//@CRDT: 19960610
int io_lstat_ora::SetEnd()
{
	int Status = TRUE;
	
	if (!io_lstat_ins->SaveEnd())
	{
		Status = FALSE;
	}

	if (!io_lstat_upd->UpdateEnd())
	{
		Status = FALSE;
	}

	delete io_lstat_ins;
	delete io_lstat_upd;
	io_lstat_ins = 0;
	io_lstat_upd = 0;

	return Status;
}

