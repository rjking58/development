
#include <iostream.h>



extern "C" pascal int Times2(int	a_number);




void main()
{
	int i;

	Times2(2);

	cin >> i;	
}
