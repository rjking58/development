// This is the main DLL file.

#include "stdafx.h"
#include "..\UnManagedDLL\UnManagedDLL.h"
#include "UnManagedDLLTests.h"

namespace UnManagedDLLTests 
{
	void UnManagedTests::SimpleTest()
	{
		Assert::IsTrue(true);

		TestClass *tc = new TestClass();

		tc->SetVal(10);
		Assert::AreEqual(10,tc->GetVal());
		tc->SetVal(20);
		Assert::AreEqual(20,tc->GetVal());
		tc->SetVal(30);
		Assert::AreEqual(30,tc->GetVal());

		delete tc;
	}
}

