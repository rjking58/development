#pragma once

#if !defined(_NO_EXPORT)
    #if defined(UNMANAGED_DLL_EXPORTS)
        #define UNMANAGED_DLL_API __declspec(dllexport)
    #else
        #define UNMANAGED_DLL_API __declspec(dllimport)
    #endif
#else
    #define UNMANAGED_DLL_API
#endif

class UNMANAGED_DLL_API TestClass
{
private:
	int m_val;
public:
	TestClass();

	void SetVal(int p_val);
	int GetVal();
};