// This is the main DLL file.

#include "stdafx.h"
#include "..\UnManagedDLL\UnManagedDLL.h"
#include "UnManagedTests2.h"

namespace UnManagedDLLTests2
{
	void UnManagedTests2::SimpleTest()
	{
		Assert::IsTrue(true);

		TestClass *tc = new TestClass();

		tc->SetVal(10);
		Assert::AreEqual(10,tc->GetVal());
		tc->SetVal(20);
		Assert::AreEqual(20,tc->GetVal());
		tc->SetVal(30);
		Assert::AreEqual(30,tc->GetVal());

		delete tc;
	}
	void UnManagedTests2::AnotherTest()
	{

		Assert::IsTrue(false);
	}
}

