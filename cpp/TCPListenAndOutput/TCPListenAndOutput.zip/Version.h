
#pragma once

// Master version file for the following products:
// Dell UCM

#define MASTER_VERSION						1,3,0,4
#define MASTER_VERSION_STR					"1.3.0\0"
#define MASTER_BUILD_ID						"2233testb\0"
#define MASTER_VERSION_PRODUCT_NAME_STR		"Dell Universal Connection Manager\0"
#define MASTER_COPYRIGHT					"Copyright (C) 2008"
#define MASTER_COMMENTS						"www.smithmicro.com"
#define MASTER_COMPANYNAME					"Smith Micro Software, Inc."
