Tools and documentation for the .S3D file format, which
is a simple text-file format used at Terminal Reality
to store a texture-mapped triangle mesh.

s3dxport.dle	Exporter plugin for 3DS Max 2.x
s3dxport3.dle	Exporter plugin for 3DS Max 3.x
s3dxport4.dle	Exporter plugin for 3DS Max 4.x
s3dmport.dli	Importer plugin for 3DS Max 2.x
s3dmport3.dli	Importer plugin for 3DS Max 3.x
s3dmport4.dli	Importer plugin for 3DS Max 4.x
s3dformat.pdf	Format documentation, in Adobe PDF format
