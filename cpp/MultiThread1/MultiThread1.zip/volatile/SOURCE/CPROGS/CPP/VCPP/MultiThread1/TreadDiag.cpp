// TreadDiag.cpp : implementation file
//

#include "stdafx.h"
#include <afxmt.h>
#include "MultiThread1.h"
#include "TreadDiag.h"
#include "strstrea.h"
#include "threadfunc.h"

// maximum lines to put in edit box..
const int MAX_EDIT_LINES = 28;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CCriticalSection AddStringCS;


/////////////////////////////////////////////////////////////////////////////
// CTreadDiag dialog


CTreadDiag::CTreadDiag(CWnd* pParent /*=NULL*/)
	:	CDialog(CTreadDiag::IDD, pParent),
		addCnt(0),
		mNextID(0),
		currThread(0)
{
	EnableAutomation();

	//{{AFX_DATA_INIT(CTreadDiag)
	m_Edit = _T("");
	//}}AFX_DATA_INIT
}


void CTreadDiag::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CDialog::OnFinalRelease();
}

void CTreadDiag::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTreadDiag)
	DDX_Text(pDX, IDC_EDIT1, m_Edit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTreadDiag, CDialog)
	//{{AFX_MSG_MAP(CTreadDiag)
	ON_BN_CLICKED(IDC_NEWTREAD, OnNewtread)
	ON_MESSAGE(WM_USER_UPDATE_THREADDIAG,DoUpdateData)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CTreadDiag, CDialog)
	//{{AFX_DISPATCH_MAP(CTreadDiag)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_ITreadDiag to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {9D89D980-0BCB-11D3-BEA3-0040052C8ABC}
static const IID IID_ITreadDiag =
{ 0x9d89d980, 0xbcb, 0x11d3, { 0xbe, 0xa3, 0x0, 0x40, 0x5, 0x2c, 0x8a, 0xbc } };

BEGIN_INTERFACE_MAP(CTreadDiag, CDialog)
	INTERFACE_PART(CTreadDiag, IID_ITreadDiag, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreadDiag message handlers


//void CTreadDiag::OnAddstr() 
//{
	// TODO: Add your control notification handler code here
//	ostrstream additional;

//	additional << "new line:" << addCnt << ends;
//	addCnt++;

//	AddString(additional.str(),TRUE);

//	additional.rdbuf()->freeze(0);

//	UpdateData(FALSE);
//}

void CTreadDiag::SyncEditArray()
{
	int arSz = mEditArray.GetSize();
	int arCurr;

	ostrstream newText;

	for(arCurr = 0; arCurr<arSz; arCurr++)
	{
		newText <<  mEditArray.GetAt(arCurr) << "\x0d\n";
	}
	newText << ends;
	m_Edit = newText.str();
	newText.rdbuf()->freeze(0);
}


void CTreadDiag::AddString(CString str,BOOL doUpdate)
{
	// start of critical section..
	AddStringCS.Lock();


	int arSz = mEditArray.GetSize();
	int arCurr;

	if(arSz >= MAX_EDIT_LINES)
	{
		// shift up one..
		for(arCurr = 0; arCurr < arSz-1; arCurr++)
		{
			mEditArray.SetAtGrow(arCurr,mEditArray.GetAt(arCurr+1));
		}
		arSz -= 1;
	}

	mEditArray.SetAtGrow(arSz,str);

	// Blow it into m_Edit
	SyncEditArray();
	// update please..
	if(doUpdate)
	{
	}

	AddStringCS.Unlock();
	
	// end of critical section.

}

int CTreadDiag::GetID()
{
	return mNextID++;
}


void CTreadDiag::OnNewtread() 
{
	// TODO: Add your control notification handler code here
	// do it stupid for now... create up to three threads..
	if(currThread < 10)
	{
		threads[currThread] = 
			AfxBeginThread(ThreadFunction, 
								this );
		currThread++;
	}
	
}


void CTreadDiag::DoUpdateData() 
{
	// TODO: Add your control notification handler code here
//	ostrstream additional;

//	additional << "new line:" << addCnt << ends;
//	addCnt++;

//	AddString(additional.str(),TRUE);

//	additional.rdbuf()->freeze(0);

	UpdateData(FALSE);
}

