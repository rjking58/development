class ModuleList;

//=============================================================================
// ModuleInstance class:
//      Represents exactly one loaded module (DLL).  DLLs with the same
//      name, but in different directories are distinct.  Likewise, if the
//      the DLL is loaded at a different address is multiple processes, each
//      distinct load address is represented by a unique ModuleInstance.
//
//      Besides the HMODULE and name, the class also keeps a list of process
//      IDs that have this module loaded.
//=============================================================================
class ModuleInstance
{
    friend class ModuleList;
    
    ModuleInstance * m_pNext;

    DWORD   m_nProcessReferences;  // Number of referencing process IDs
    PDWORD  m_pProcessReferences;  // Array of process IDs (initially empty)
    
    public:

    ModuleInstance( HMODULE hModule, PSTR pszName );
    ~ModuleInstance(void);
    
    BOOL    IsEqual( HMODULE hModule, PSTR pszName );
    BOOL    AddProcessReference( DWORD pid );
    DWORD   EnumerateProcessReferences( int & enumHandle );
    DWORD   GetNumberOfProcessReferences( void ){return m_nProcessReferences;}    
            
    PSTR    m_pszName;
    HMODULE m_hModule;
};
typedef ModuleInstance * PModuleInstance;

//=============================================================================
// ModuleList class:
//      A simple linked list container for instances of the ModuleInstance
//      class.  Methods are provided to lookup, add, and enumerate the list.
//=============================================================================
class ModuleList
{
    PModuleInstance m_pModuleInstanceList;
    
    public:

    ModuleList( void ){ m_pModuleInstanceList = 0; }
    ~ModuleList( void ){ Clear(); }
    void Clear( void );     // Empty the list

    PModuleInstance Lookup( HMODULE hModule, PSTR pszName );
    PModuleInstance Add( HMODULE hModule, PSTR pszName );
    PModuleInstance Enumerate( PModuleInstance pModInst );
    
};

//=============================================================================
// ProcessIdToNameMap class:
//      A simple array based mapping between process IDs and the complete
//      pathname to the EXE for the process.
//=============================================================================
class ProcessIdToNameMap
{
    struct ProcessIdName    // A private class.  Each process has one instance
    {
        DWORD   m_pid;
        PSTR    m_pszName;
    };
    
    ProcessIdName * m_array;
    DWORD           m_nEntries;
    
    public:
    
    ProcessIdToNameMap( void ){ m_array = 0; m_nEntries = 0; }
    ~ProcessIdToNameMap( void ){ Clear(); }
    void Clear( void );
        
    BOOL Add( DWORD pid, PSTR pszName );
    PSTR Lookup( DWORD pid );   
};
