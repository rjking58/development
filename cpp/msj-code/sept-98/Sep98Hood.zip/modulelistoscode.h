BOOL
PopulateModuleList_ToolHelp32(
    ModuleList & modList,
    ProcessIdToNameMap &pidNameMap );

BOOL
PopulateModuleList_PSAPI(
    ModuleList & modList,
    ProcessIdToNameMap &pidNameMap );
