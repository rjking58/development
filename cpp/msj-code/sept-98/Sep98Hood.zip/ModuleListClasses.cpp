#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include "ModuleListClasses.h"

ModuleInstance::ModuleInstance( HMODULE hModule, PSTR pszName )
{
    m_pNext = 0;
    m_pszName = strdup( pszName );
    m_hModule = hModule;
    m_nProcessReferences = 0;
    m_pProcessReferences = 0;

}

ModuleInstance::~ModuleInstance(void)
{
    free(m_pszName);    // We strdup'd this in the constructor
    if ( m_pProcessReferences )
        free( m_pProcessReferences );
}
    
BOOL
ModuleInstance::IsEqual( HMODULE hModule, PSTR pszName )
{
    // A module instance is consider the same if it has the same name
    // and HMODULE (load address)
    if ( (m_hModule == hModule) && (0 == stricmp(pszName, m_pszName)) )
        return TRUE;
        
    return FALSE;
}

BOOL
ModuleInstance::AddProcessReference( DWORD pid )
{
    if ( 0 == (m_nProcessReferences % 10) ) // Do we need to grow the array?
    {
        // Reallocate the array
        m_pProcessReferences = (PDWORD)realloc( m_pProcessReferences,
                                (m_nProcessReferences+10) * sizeof(DWORD) );
    }

    // Add the pid to the array, and bump up the count of referencing processes 
    m_pProcessReferences[m_nProcessReferences++] = pid;

    return TRUE;        
}

DWORD
ModuleInstance::EnumerateProcessReferences( int & enumHandle )
{
    // The enumHandle parameter is really just an index into the pid array
    
    // Have we reached the end of the array?
    if ( (DWORD)enumHandle == m_nProcessReferences )
        enumHandle = -1;

    if (-1 == enumHandle )  // -1 means the enumeration is over.
        return -1;

    // Normal case: just index into the array and return what's there
    return m_pProcessReferences[enumHandle++];
}
        
//=============================== ModuleList:: methods =======================
void
ModuleList::Clear( void )
{
    // Walk through the linked list, freeing ModuleInstance entries as
    // they're encountered.
    PModuleInstance pCurrInst = m_pModuleInstanceList;

    while ( pCurrInst )
    {
        PModuleInstance pNextInst = pCurrInst->m_pNext;

        delete ( pCurrInst );
                
        pCurrInst = pNextInst;  // Advance to next ModuleInstance
    }
    
    m_pModuleInstanceList = 0;
}

PModuleInstance
ModuleList::Lookup( HMODULE hModule, PSTR pszName )
{
    // Walk through the linked list, comparing the HMODULE and filename to
    // the entries already in the list
    PModuleInstance pCurrInst = m_pModuleInstanceList;
    
    while ( pCurrInst )
    {
        if ( pCurrInst->IsEqual( hModule, pszName ) )
            return pCurrInst;       // We found a match!
            
        pCurrInst = pCurrInst->m_pNext; // Advance to next ModuleInstance
    }
    
    return 0;
}

PModuleInstance
ModuleList::Add( HMODULE hModule, PSTR pszName )
{
    // Create a new ModuleInstance
    PModuleInstance pNewInst = new ModuleInstance( hModule, pszName );

    // Put the new ModuleInstance at the head of the linked list
    pNewInst->m_pNext = m_pModuleInstanceList;
    m_pModuleInstanceList = pNewInst;
    
    return pNewInst;
}

PModuleInstance
ModuleList::Enumerate( PModuleInstance pModInst )
{
    if ( 0 == pModInst )    // Passing 0 begins the enumeration
        return m_pModuleInstanceList;
        
    return pModInst->m_pNext;
}

//======================= ProcessIdToNameMap:: methods ======================

void
ProcessIdToNameMap::Clear( void )
{
    if ( m_array )
        free( m_array );

    m_nEntries = 0; 
}
    
BOOL
ProcessIdToNameMap::Add( DWORD pid, PSTR pszName )
{
    if ( 0 == (m_nEntries % 10) )   // Do we need to grow the array?
    {
        // Reallocate the array
        m_array = (ProcessIdName*)realloc(
                        m_array, (m_nEntries+10) * sizeof(ProcessIdName) );
    }
    
    m_array[m_nEntries].m_pid = pid;
    m_array[m_nEntries].m_pszName = strdup( pszName );

    m_nEntries++;
    
    return TRUE;        
}

PSTR
ProcessIdToNameMap::Lookup( DWORD pid )
{
    for ( DWORD i = 0; i < m_nEntries; i++ )
    {
        if ( pid == m_array[i].m_pid )
            return m_array[i].m_pszName;
    }

    return 0;
}
