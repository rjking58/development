/*	Eratosthenes Sieve Prime Number Program in C, Byte January 1983.
 *	The code has been corrected to produce primes correctly.
*/
#include <stdio.h>
#include <iostream.h>

const int TRUE	=1;
const int FALSE	=0;
const int NITER	=1;
const int SIZE	=6000;

char its_a_prime[SIZE+1]={0};
char not_prime;

void main (void)
{
  register int i,k;
  int iterations, count_of_primes;

  cout << NITER << "iterations: ";

  /* Do sieve once */
  for( iterations = 1; iterations <= NITER; iterations++ )     
  {
    count_of_primes = 0;
    for( i = 0; i <= SIZE; i++)     /* set all flags true */
      its_a_prime[i] = TRUE;

    for( i = 2; i <= SIZE; i++ )
    {
      if ( its_a_prime[i] )        /* found a prime */
      {
        for ( k = i + i; k <= SIZE; k += i )
          its_a_prime[k] = FALSE;   /* Cancel its multiples */
        count_of_primes++;
      }
    }
  }
   
  for (i = 2; i <= SIZE; i++)
  {
	cout << i;

    if(its_a_prime[i])
    {
		cout << " p";
    }
    else
    {
    	cout << "  ";
    }
    /* verify */
    not_prime = FALSE;
    k = 2;
    while( (k < i) && (not_prime == FALSE))
    {
      if( (i % k) == 0 )
      {
        not_prime = TRUE; 
      }
      k++;
    }
    if( not_prime == TRUE )
    {
		cout << endl;
    }
    else
    {
		cout << "v" << endl;
    }
  }
  cout << endl << count_of_primes << " primes" << endl;

}
