#create a string..
myline = "x"

#print the directory of all methods on this string..
dir(myline)

#getting help on a given method on string..
#help(myline.zfill)
