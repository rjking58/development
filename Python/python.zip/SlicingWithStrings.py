
mystring = "0123456789"

print("mystring=",mystring)

print("mystring[1:]")
print(mystring[1:])

print("mystring[5:]")
print(mystring[5:])

print("mystring[5:7]")  # 7 is NOT included..
print(mystring[5:7])

print("mystring[:-1]")  # negative numbers start exclusion from the end..
print(mystring[:-1])

print("mystring[:-2]")  # negative numbers start exclusion from the end..
print(mystring[:-2])
