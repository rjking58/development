#first python script
import sys          #load a library module
print(sys.platform)
print(2**100)       #raise to power of two
x='Spam!'
print(x*8)          #string repetition

