cnt=20
curr_val=0
while curr_val < cnt:
    print( curr_val)
    curr_val += 1

mystr = "spam"
#while mystr is not empty..
while mystr:
	print (mystr[0], end=' ')
	print (mystr)
	mystr = mystr[1:]
