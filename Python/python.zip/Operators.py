#bit manipulations
#and.
print( "and:",bin(3) ,"&",bin(5),"=",bin(3&5))

#or
print( "or:",bin(3) ,"|",bin(5),"=",bin(3|5))

#xor

print( "xor:",bin(3) ,"^",bin(5),"=",bin(3^5))

#twos compl
print( "twos compl: ~",bin(3),"=",bin(~3))

#left shift
print( "left shift: ",bin(5),"<< 2","=",bin(5<<2))

#right shift
print( "left shift: ",bin(5),">> 2","=",bin(5>>2))

#floating div
print( "floating div:", "18./8. =",18./8.)

#floating div
print( "floating div:", "18./8 =",18./8)

#floating div
print( "floating div:", "18/8. =",18/8.)

#integer div
print( "integer div:", "18/8 =",18/8)

#operators used with assignment..
print( "x=2")
x=2
print( "x+=3")
x+=3
print( x)


#normal c comparison ops apply..
print( "1<2 = ",1<2)
print( "1>2 = ",1>2)
print( "1<=2 = ",1<=2)
print( "1>=2 = ",1>=2)
print( "1==2 = ",1==2)
print( "1!=2 = ",1!=2)

