def FahrToCentigrade ():
    print( "Enter Temp in F:")
    inputTemp = input()
    print ((int(inputTemp)-32)*(5./9.)," C")
