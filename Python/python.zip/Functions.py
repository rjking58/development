def add_nums(num1,num2):
    return num1 + num2

print( add_nums(1,2))
print( add_nums(3,4))
