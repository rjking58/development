
def myfunc(x):
    return x+2

