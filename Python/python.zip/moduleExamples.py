import math
import random

print( "math.hypot(3,4)=" , math.hypot(3,4))
print( "math.log10(100)=" , math.log10(100))
print( "math.sqrt(3.44)=" , math.sqrt(3.44))
theRoot = math.sqrt(3.44)
theRootSquared = theRoot * theRoot
print(theRoot)

print( "math.pi=",math.pi)

