#import this into a live session (or another file?)
# then type >print(myfile.title) :)
title="The Meaning of Life"
