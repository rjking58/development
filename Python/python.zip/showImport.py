import myfile

print ("myfile.title[" + myfile.title + "]")
