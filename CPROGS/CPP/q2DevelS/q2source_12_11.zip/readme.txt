Quake II 12/11/97 public code release
-------------------------------------

This source code distribution is only for hard-core people that are going to
spend a lot of time pouring over it.  This is NOT a how-to-make-levels-for-q2
type dsitribution!

The files readme_7_1.txt and readme_9_17.txt are what little documentation I
had for our code licensees.  They aren't completely up to date, but they
are the only information I have to give you right now.

The instructions cannot be followed directly, because you aren't getting all
the files that the full licensees do, but they are still good for giving a
general overview.

I included a quick unpack program to allow you to extract the textures (or
anything else you want) from the quake 2 .pak file.  This will be necessary
for using our editor (but it would be a cool idea for other editors to read
textures directly from the pak file!).  I wrote it in java, so you will
need to install sun's java run time environment to use it:

http://java.sun.com/products/jdk/1.1/jre/index.html

Get used to it -- most of our utilities from here on out will probably be
java based.

We will be releasing the updated game source code after the point release,
and it will likely include many changes.  Don't say we didn't warn you.

I don't warrant that any of these tools will be usable by normal people.
Our tools are designed for our systems -- high end OpenGL accelerators
with lots of memory, and they probably aren't apropriate for most ameture
work.  They should serve as good source material for people that want to
create more down to earth tools, though.

A specific warning:  our editor seems to cause several 3dlabs drivers to
blue screen NT at various times... Be careful.

As usual, please please please don't bombard me with questions about this.

Have fun, and I hope you can learn a thing or two from it.

John Carmack
