
#include "qbsp.h"

vec3_t draw_mins, draw_maxs;
qboolean	drawflag;

void Draw_ClearWindow (void)
{
}

//============================================================

#define	GLSERV_PORT	25001


void GLS_BeginScene (void)
{
}

void GLS_Winding (winding_t *w, int code)
{
}

void GLS_EndScene (void)
{
}
