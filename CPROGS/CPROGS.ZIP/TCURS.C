#include <stdio.h>


main()
  {
  int top,bottom;
  printf("input top:");
  scanf("%d",&top);
  printf("input bottom:");
  scanf("%d",&bottom);
  bios_sc((char)top,(char)bottom);
  }
