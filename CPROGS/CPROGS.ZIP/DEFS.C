#if defined(DIRECT36)

#elif	defined(DIRECT38)

#elif defined(ALEXANDER)

#else
/* force = syntax_error */ /* force a syntax error since no */
                            /* machine type was specified    */
#endif

/* 000000000011111111112222222222333333	 */
/* 012345678901234567890123456789012345	 */
