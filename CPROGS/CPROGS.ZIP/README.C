Assignment for week 3 :
        1. In spite of my best efforts, I'm afraid some bugs crept in into
the program. Gotta debug to make it run !!!
        2. Add a "Phone #" and a "Social Security #" field for each entry in
the database. Also, add a bit variable to keep track of vacant slots, instead
of whatever is being used currently.
        3. Add in two additional operations for inquiring a single account's
particulars; and for updating a single account's particulars.
        4. Since the user would typically be queried for her/his account #
for certain operations, give the account # when a new account is created.
        5. Make sure the user interface is properly formatted for all
possible conditions.
        6. Be imaginative ! Add more features, or niftier programming !!!
