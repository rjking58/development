#include <stdio.h>
#include <string.h>
#include <alloc.h>
#include <process.h>

#define TRUE        -1
#define FALSE        0
#define ALMOST       1   /* returned when a closure matches a NULL */
#define ENDSTR      '\0'
#define EOL         '$'
#define BOL         '^'
#define NEGATE      '^'
#define CCL         '['
#define NCCL        ']'
#define CCLEND      ']'
#define ANY         '.'
#define DASH        '-'
#define OR          '|'
#define ESCAPE      '\\'
#define LPAREN      '('
#define RPAREN      ')'
#define CLOSURE     '*'
#define POS_CLO     '+'
#define ZERO_ONE    '?'
#define LITCHAR     'c'
#define END_TERM    'e'
#define FS_DEFAULT  "[ \t]+"


#define MAXSTR      1024
#define MAXPAT      2 * MAXSTR
#define MAXFIELD    128


/*
 * globals  (also defined in awklib.h for use by applications.)
 *
 */

int  RSTART;
int  RLENGTH;
int  NF;
char *FS;
char *FS_PAT;
char *FIELDS[MAXFIELD];

/*
 *  internal function prototypes.
 */











